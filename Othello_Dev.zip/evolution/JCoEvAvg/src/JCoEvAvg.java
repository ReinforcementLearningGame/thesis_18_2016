import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;


public class JCoEvAvg 
{
	private static double[][] brains;	// each brain is actually the parameters to be optimized
	private static double[]   parent;	// the parent contains the best brain after each generation;
	private static int[] fitness;		// the fitness of each brain
	
	private static int POPULATION;		// the population of the candidate solutions
	private static int GENERATIONS;		// the number of generations the evolutionary algorithm should applied
	private static int GEN_GAMES;		// games played per generation
	private static int nWeights;		// the number of weights of the Neural Net
	
	static int netSave;
	static int netType;
	static int nnDepth;
	
	// for multi-threaded tasks...
	private static int nThreads;		// number of threads
	private static Thread[] tds;		// an array of threads
	
	private static final Random rvalue = new Random();
	
	
	static class Competition implements Runnable
	{
		@Override
		public void run()
		{
			int ds1, ds2;	// number of disks for each player, after one game
			int thrGames;	// number of games per thread
			int thrIndex;	// index of current thread
			int min, max;	// lower and upper limit
			
			OthAIPlayer  p1 , p2;	// the competing players
			OthBoard board = new OthBoard();
			
			thrGames = POPULATION / nThreads;
			thrIndex = Integer.parseInt(Thread.currentThread().getName());
			
			min = thrIndex*thrGames;
			if(thrIndex == nThreads-1) max = POPULATION; else max = min + thrGames;
			
			p1 = null;
			p2 = null;
			
			if(netType == 0) 
			{
				p1 = new NN_64_16x8_8_1(); 
				p2 = new NN_64_16x8_8_1(); 
			}
			else
			if(netType == 1) 
			{
				p1 = new NN_64_16x8_8_4_1(); 
				p2 = new NN_64_16x8_8_4_1();; 
			}
			else
			if(netType == 2) 
			{
				p1 = new NN_64_91_40_10_1(); 
				p2 = new NN_64_91_40_10_1(); 
			}
			else
			if(netType == 3) 
			{
				p1 = new NN_64_40_10_1(); 
				p2 = new NN_64_40_10_1(); 
			}

			// set the players's search depth
			p1.setDepth(nnDepth);
			p2.setDepth(nnDepth);
			
			// start the tournament...
			for(int i = min; i < max; ++i)
			{	
				// set the player's brain
				p1.setBrain(brains[i]);
				
				for(int j = i + 1; j < POPULATION; ++j)
				{
					// set the player's brain
					p2.setBrain(brains[j]);
					
					// set up the board and the players's color
					board.reset();
						
					p1.setColor(OthColors.black);
					p2.setColor(OthColors.white);
						
					// this is the first game where p1 plays black and p2 plays white
					OthManager.playQuietly(board, p1, p2);
					
					ds1 = board.getDisksOfColor(OthColors.black);
					ds2 = board.getDisksOfColor(OthColors.white);
					
					synchronized(this)
					{
						++GEN_GAMES;
						
						if(ds1 > ds2)
						{
							fitness[i] += 2000 + ds1 - ds2;
						}	
						else
						if(ds1 < ds2)
						{
							fitness[j] += 2000 + ds2 - ds1;
						}
						else
						{
							fitness[i] += 1000;
							fitness[j] += 1000;
						}
					}

					// setting up the board and the players's color
					board.reset();
						
					p2.setColor(OthColors.black);
					p1.setColor(OthColors.white);
						
					// this is the second game where p2 plays black and p1 plays white
					OthManager.playQuietly(board, p2, p1);

					ds2 = board.getDisksOfColor(OthColors.black);
					ds1 = board.getDisksOfColor(OthColors.white);
					
					synchronized(this)
					{
						++GEN_GAMES;
						
						if(ds2 > ds1)
						{
							fitness[j] += 2000 + ds2 - ds1;
						}
						else
						if(ds2 < ds1)
						{
							fitness[i] += 2000 + ds1 - ds2;
						}
						else
						{
							fitness[i] += 1000;
							fitness[j] += 1000;
						}
					}
				}
			}
			
		}	
	}
	
	// this is a round-robin tournament
	private static void playTournament()
	{
		// first we reset brains's fitness before they compete again
	    for(int i = 0; i < POPULATION; ++i)
	    {
	    	fitness[i] = 0;
	    }
	    
	    // and also the games per generation
	    GEN_GAMES = 0;
		
	    // instantiate the class object
		Competition competition = new Competition();
		
		// create the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i] = new Thread(competition, Integer.toString(i));
		}
		
		// start the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i].start();
		}
		
		// wait for all threads to complete their task
		for(int i = 0; i < nThreads; ++i)
		{
			try 
			{
				tds[i].join();
			} 
			catch (InterruptedException e) 
			{
				// nothing to do...
				System.err.println("ERROR: Thread Interruption... Results might be inaccurate");
			}
		}
	}
	
	// saves the best brain in Disk and also some tournament statistics ...
	private static void saveBrain(double[] brain, String filename)
	{
		PrintWriter writer = null;
		
		try 
		{
			writer = new PrintWriter(filename);
			for(int i = 0; i < brain.length; ++i)
			{
				writer.print(brain[i] + " ");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrain()\nBrain (" + filename + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}

	private static double[] loadBrain(String filename)
	{
		BufferedReader reader = null;
		double[] brains = null;
		
		try 
		{
			String line;
			reader = new BufferedReader(new FileReader(filename));
			
			line = reader.readLine();
			line = line.trim();
			
			String[] weights = line.split("\\s");
			
			if(weights.length != nWeights)
			{
				System.err.println("ERROR: File (" + filename + ") has invalid Data ...");
				System.exit(1);
			}
			else
			{
				brains = new double[weights.length];
				for(int i = 0; i < weights.length; ++i) brains[i] = Double.parseDouble(weights[i]);
			}
		}
		catch (IOException e)
		{
			System.err.println("ERROR: I/O in method loadBrain()\nBrain (" + filename + ") not loaded ...");
		}
		finally
		{
			if(reader != null)
				try 
				{
					reader.close();
				} 
				catch (IOException e)
				{
					// nothing to do here...
				}
		}
		
		return brains;
	}
	
	
	public static void main(String[] arg)
	{
		if(arg.length != 5 && arg.length != 6)
		{
			System.err.println("Correct Usage: java -jar JCoEvAvg.jar [population] [nnType] [nnDepth] [threads] [option]");
			System.err.println("option = 0: Save Brains (both parent and the best of the generation) to Disk");
			System.err.println("option = 1 [file_name]: Load Brain from Disk\n");
			System.err.println("NEURAL NETWORK TYPE");
			System.err.println("type = 0: 64-16x8-8-1,		type = 1: 64-16x8-8-4-1");
			System.err.println("type = 2: 64-91-40-10-1,	type = 3: 64-40-10-1");
			System.exit(1);
		}

		// parsing arguments ...
		POPULATION  = Integer.parseInt(arg[0]);	// genetic population
		netType  = Integer.parseInt(arg[1]); 	// Neural Network Type
		nnDepth  = Integer.parseInt(arg[2]); 	// the search depth of the AI
		nThreads = Integer.parseInt(arg[3]);	// The number of threads
		int option  = Integer.parseInt(arg[4]);	// an option
		
		// testing arguments ...
		if(POPULATION < 2)
		{
			System.err.println("ERROR: Insufficient Population");
			System.exit(1);
		}
		
		if(nnDepth < 1)
		{
			System.err.println("ERROR: Invalid Search Depth");
			System.exit(1);
		}
		
		if(netType < 0 || netType > 3)
		{
			System.err.println("ERROR: Invalid Network Type");
			System.exit(1);
		}
		
		if(option != 0 && option != 1)
		{
			System.err.println("ERROR: Invalid Option");
			System.exit(1);
		}
		
		if(option == 1 && arg.length != 6)
		{
			System.err.println("ERROR: Invalid Number of Arguments");
			System.exit(1);
		}
		
		if(nThreads < 1 || nThreads > POPULATION)
		{
			System.err.println("ERROR: Invalid Number of Threads. Default value (1) is Used");
			nThreads = 1;
		}
		
		if(netType == 0) nWeights = 1185;
		else
		if(netType == 1) nWeights = 1217;
		else
		if(netType == 2) nWeights = 5900;
		else
		if(netType == 3) nWeights = 3021;
		
		GENERATIONS = 10000000;					// maximum number of generations
		double step = 1/Math.sqrt(nWeights);	// maximum noise step to be added to each weight
		double beta = 0.05;						// for use in arithmetic averaging...
		
		// create and initialize the first generation of "brains"
		brains = new double[POPULATION][nWeights];
		// create and initialize their respective fitness values
		fitness = new int[POPULATION];
		// create and initialize the parent
		parent = new double[nWeights];
		// create the thread pool
		tds = new Thread[nThreads];
		
		int START_GENERATION = 1;
		
		if(option == 1)
		{

			// for the new START_GENERATION we assume the file is in the form p_xxx
			START_GENERATION = Integer.parseInt(arg[5].substring(arg[5].indexOf("_") + 1)) + 1;
			double[] b = loadBrain(arg[5]);
			for(int i = 0; i < nWeights; ++i) parent[i] = b[i];
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		System.out.println("Starting (1,λ) Co-evolutionary Algorithm ... ");
		// *************************************************************************
		//             CO-EVOLUTIONARY (1,λ) ALGORITHM STARTS HERE 
	    // *************************************************************************
		
		int bestFitness;		// the best fitness of this generation
		int worstFitness;		// the worst fitness of this generation
		int bestFtIndex;		// array index of the best "brain"
		long iniTime;
		
		for(int generation = START_GENERATION; generation < GENERATIONS; ++generation)
		{
			iniTime = System.currentTimeMillis();
			
			// show some info about the generation number
			System.out.println("GENERATION: " + generation);
			
			// first we add some noise to the weights of the brains
			for(int i = 0; i < POPULATION; ++i)
			{
				for(int w = 0; w < nWeights; ++w)
				brains[i][w] = parent[w] + step*rvalue.nextGaussian();
			}

			// next, a round-robin tournament takes place
			playTournament();
			
			// show info about the games played
			System.out.printf("(%d) GAMES PLAYED - ", GEN_GAMES);
			
			// show elapsed time
			System.out.printf("ELAPSED TIME: %.2f sec\n", (double)(System.currentTimeMillis() - iniTime)/1000.0);
			
			// we search for the best (and the worst) "brain" of its generation.		
			bestFitness = Integer.MIN_VALUE;
			bestFtIndex = Integer.MIN_VALUE;
			worstFitness = Integer.MAX_VALUE;
			
			for(int i = 0; i < POPULATION; ++i)
			{
				if(fitness[i] > bestFitness)
				{
					bestFitness = fitness[i];
					bestFtIndex = i;
				}
				
				if(fitness[i] < worstFitness)
				{
					worstFitness = fitness[i];
				}
			}
			
			// and update the parent's weights...
			for(int w = 0; w < nWeights; ++w)
			parent[w] = parent[w] + beta*(brains[bestFtIndex][w] - parent[w]);
		
			// we finally save this best parent "brain"
			saveBrain(parent, ("b_" + generation));
			// the best "brain" of its generation
			saveBrain(brains[bestFtIndex], ("gen_" + generation));
				
			// and show some additional info
			double meanF = 0.0;
			double stdF = 0.0;
				
			for(int i = 0; i < POPULATION; ++i) meanF += fitness[i];
			meanF = meanF/POPULATION;
				
			for(int i = 0; i < POPULATION; ++i) stdF += (fitness[i] - meanF)*(fitness[i] - meanF);
			stdF = Math.sqrt(stdF/POPULATION);
				
			System.out.printf("Best Fitness: %d\tWorst Fitness: %d\n", bestFitness, worstFitness);
			System.out.printf("Mean Fitness: %.1f\tstd-DEV: %.3f\n", meanF, stdF);
			System.out.println("-------------\n");
		}
	}
}
