package com.vasmakk.othello;

public class AndOthBoard
{	
	private int[] mSquares;			// an 64 element array contains each square's colors
	private int mTurn;				// +1 or -1 indicates who plays the current position
	
	private static final int BLACK = AndOthColors.black;
	private static final int WHITE = AndOthColors.white;
	
	// the constructors ...
	
	public AndOthBoard()
	{
		mSquares = new int[64];

		mSquares[27] = WHITE; 
		mSquares[36] = WHITE;
		mSquares[28] = BLACK;
		mSquares[35] = BLACK;
		
		mTurn = BLACK;
	}
	
	public AndOthBoard(int[] squares)
	{
		mSquares = new int[64];
		setBoard(squares);
	}
	
	
	// the setters ...
	
	public void setTurn(int turn)
	{
		mTurn = turn;
	}
	
	public void setBoard(int[] squares)
	{
		for(int i = 0; i < 64; ++i)
		{
			mSquares[i] = squares[i];
		}
	}
	
	public void setSquareColor(int square, int color)
	{
		mSquares[square] = color;
	}
	
	
	// the getters ...	
	
	public int getTurn()
	{
		return mTurn;
	}
	
	public int[] getBoard()
	{
		int[] squares = new int[64];
		
		for(int i = 0; i < 64; ++i)
		{
			squares[i] = mSquares[i];
		}
		
		return squares;
	}
	
	public int getSquareColor(int square)
	{
		return mSquares[square];
	}
	
	public int getDisksOfColor(int color)
	{
		int disks = 0;
		for(int i = 0; i < 64; ++i)
		{
			if(mSquares[i] == color) ++disks;
		}
		
		return disks;
	}
	
	// other methods
	public void clear()
	{
		for(int i = 0; i < 64; ++i)
		{
			mSquares[i] = AndOthColors.blank;
		}
		
		mTurn = AndOthColors.blank;
	}
	
	public void reset()
	{
		clear();
		
		mSquares[27] = WHITE; 
		mSquares[36] = WHITE;
		mSquares[28] = BLACK;
		mSquares[35] = BLACK;
		
		mTurn = BLACK;
	}
	
	public void reverse()
	{
		for(int i = 0; i < 64; ++i) mSquares[i] = -mSquares[i];
		
		mTurn = -mTurn;
	}
}
