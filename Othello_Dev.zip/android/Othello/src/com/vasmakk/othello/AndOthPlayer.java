package com.vasmakk.othello;

public abstract class AndOthPlayer 
{
	protected int mColor;
	
	// the way different kind of players select and make their move, strongly differs.
	// so this method should be declared abstract ...
	public abstract AndOthMove nextMove(AndOthBoard board);
	
	
	public void setColor(int color)
	{
		mColor = color;
	}
	
	public int getColor()
	{
		return mColor;
	}
}
