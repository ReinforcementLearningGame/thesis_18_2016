// this is a spatial processing Neural Network with 64-SP(65 nodes)-40-10-1 architecture (with biases)
// this network has a total of 4710 weights

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

public class NN_64_91_40_10_1 extends OthAIPlayer
{
	private int mSearchDepth;			// maximum search depth of AI
	
	private double mScore;				// the score of the move played by AI
	private double[] mBrain;
	private double[] mMidLayer1Nodes;	// the value of each node of the middle layer #1
	private double[] mMidLayer2Nodes;	// the value of each node of the middle layer #2
	private double[] mMidLayer3Nodes;	// the value of each node of the middle layer #3
	
	private final double MAXIMUM = +2;
	private final double MINIMUM = -2;

	private final double eGreedy = 0.0;		// performs random moves from time to time...
	private final Random rvalue = new Random();
	
	private final int[][] patterns = {
	{  0, 1, 2, 8, 9,10,16,17,18 },
	{  1, 2, 3, 9,10,11,17,18,19 },
	{  2, 3, 4,10,11,12,18,19,20 },
	{  3, 4, 5,11,12,13,19,20,21 },
	{  4, 5, 6,12,13,14,20,21,22 },
	{  5, 6, 7,13,14,15,21,22,23 },
	{  8, 9,10,16,17,18,24,25,26 },
	{  9,10,11,17,18,19,25,26,27 },
	{ 10,11,12,18,19,20,26,27,28 },
	{ 11,12,13,19,20,21,27,28,29 },
	{ 12,13,14,20,21,22,28,29,30 },
	{ 13,14,15,21,22,23,29,30,31 },
	{ 16,17,18,24,25,26,32,33,34 },
	{ 17,18,19,25,26,27,33,34,35 },
	{ 18,19,20,26,27,28,34,35,36 },
	{ 19,20,21,27,28,29,35,36,37 },
	{ 20,21,22,28,29,30,36,37,38 },
	{ 21,22,23,29,30,31,37,38,39 },
	{ 24,25,26,32,33,34,40,41,42 },
	{ 25,26,27,33,34,35,41,42,43 },
	{ 26,27,28,34,35,36,42,43,44 },
	{ 27,28,29,35,36,37,43,44,45 },
	{ 28,29,30,36,37,38,44,45,46 },
	{ 29,30,31,37,38,39,45,46,47 },
	{ 32,33,34,40,41,42,48,49,50 },
	{ 33,34,35,41,42,43,49,50,51 },
	{ 34,35,36,42,43,44,50,51,52 },
	{ 35,36,37,43,44,45,51,52,53 },
	{ 36,37,38,44,45,46,52,53,54 },
	{ 37,38,39,45,46,47,53,54,55 },
	{ 40,41,42,48,49,50,56,57,58 },
	{ 41,42,43,49,50,51,57,58,59 },
	{ 42,43,44,50,51,52,58,59,60 },
	{ 43,44,45,51,52,53,59,60,61 },
	{ 44,45,46,52,53,54,60,61,62 },
	{ 45,46,47,53,54,55,61,62,63 },
	{  0, 1, 2, 3, 8, 9,10,11,16,17,18,19,24,25,26,27 },
	{  1, 2, 3, 4, 9,10,11,12,17,18,19,20,25,26,27,28 },
	{  2, 3, 4, 5,10,11,12,13,18,19,20,21,26,27,28,29 },
	{  3, 4, 5, 6,11,12,13,14,19,20,21,22,27,28,29,30 },
	{  4, 5, 6, 7,12,13,14,15,20,21,22,23,28,29,30,31 },
	{  8, 9,10,11,16,17,18,19,24,25,26,27,32,33,34,35 },
	{  9,10,11,12,17,18,19,20,25,26,27,28,33,34,35,36 },
	{ 10,11,12,13,18,19,20,21,26,27,28,29,34,35,36,37 },
	{ 11,12,13,14,19,20,21,22,27,28,29,30,35,36,37,38 },
	{ 12,13,14,15,20,21,22,23,28,29,30,31,36,37,38,39 },
	{ 16,17,18,19,24,25,26,27,32,33,34,35,40,41,42,43 },
	{ 17,18,19,20,25,26,27,28,33,34,35,36,41,42,43,44 },
	{ 18,19,20,21,26,27,28,29,34,35,36,37,42,43,44,45 },
	{ 19,20,21,22,27,28,29,30,35,36,37,38,43,44,45,46 },
	{ 20,21,22,23,28,29,30,31,36,37,38,39,44,45,46,47 },
	{ 24,25,26,27,32,33,34,35,40,41,42,43,48,49,50,51 },
	{ 25,26,27,28,33,34,35,36,41,42,43,44,49,50,51,52 },
	{ 26,27,28,29,34,35,36,37,42,43,44,45,50,51,52,53 },
	{ 27,28,29,30,35,36,37,38,43,44,45,46,51,52,53,54 },
	{ 28,29,30,31,36,37,38,39,44,45,46,47,52,53,54,55 },
	{ 32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59 },
	{ 33,34,35,36,41,42,43,44,49,50,51,52,57,58,59,60 },
	{ 34,35,36,37,42,43,44,45,50,51,52,53,58,59,60,61 },
	{ 35,36,37,38,43,44,45,46,51,52,53,54,59,60,61,62 },
	{ 36,37,38,39,44,45,46,47,52,53,54,55,60,61,62,63 },
	{  0, 1, 2, 3, 4, 8, 9,10,11,12,16,17,18,19,20,24,25,26,27,28,32,33,34,35,36 },
	{  1, 2, 3, 4, 5, 9,10,11,12,13,17,18,19,20,21,25,26,27,28,29,33,34,35,36,37 },
	{  2, 3, 4, 5, 6,10,11,12,13,14,18,19,20,21,22,26,27,28,29,30,34,35,36,37,38 },
	{  3, 4, 5, 6, 7,11,12,13,14,15,19,20,21,22,23,27,28,29,30,31,35,36,37,38,39 },
	{  8, 9,10,11,12,16,17,18,19,20,24,25,26,27,28,32,33,34,35,36,40,41,42,43,44 },
	{  9,10,11,12,13,17,18,19,20,21,25,26,27,28,29,33,34,35,36,37,41,42,43,44,45 },
	{ 10,11,12,13,14,18,19,20,21,22,26,27,28,29,30,34,35,36,37,38,42,43,44,45,46 },
	{ 11,12,13,14,15,19,20,21,22,23,27,28,29,30,31,35,36,37,38,39,43,44,45,46,47 },
	{ 16,17,18,19,20,24,25,26,27,28,32,33,34,35,36,40,41,42,43,44,48,49,50,51,52 },
	{ 17,18,19,20,21,25,26,27,28,29,33,34,35,36,37,41,42,43,44,45,49,50,51,52,53 },
	{ 18,19,20,21,22,26,27,28,29,30,34,35,36,37,38,42,43,44,45,46,50,51,52,53,54 },
	{ 19,20,21,22,23,27,28,29,30,31,35,36,37,38,39,43,44,45,46,47,51,52,53,54,55 },
	{ 24,25,26,27,28,32,33,34,35,36,40,41,42,43,44,48,49,50,51,52,56,57,58,59,60 },
	{ 25,26,27,28,29,33,34,35,36,37,41,42,43,44,45,49,50,51,52,53,57,58,59,60,61 },
	{ 26,27,28,29,30,34,35,36,37,38,42,43,44,45,46,50,51,52,53,54,58,59,60,61,62 },
	{ 27,28,29,30,31,35,36,37,38,39,43,44,45,46,47,51,52,53,54,55,59,60,61,62,63 },
	{  0, 1, 2, 3, 4, 5, 8, 9,10,11,12,13,16,17,18,19,20,21,24,25,26,27,28,29,32,33,34,35,36,37,40,41,42,43,44,45 },
	{  1, 2, 3, 4, 5, 6, 9,10,11,12,13,14,17,18,19,20,21,22,25,26,27,28,29,30,33,34,35,36,37,38,41,42,43,44,45,46 },
	{  2, 3, 4, 5, 6, 7,10,11,12,13,14,15,18,19,20,21,22,23,26,27,28,29,30,31,34,35,36,37,38,39,42,43,44,45,46,47 },
	{  8, 9,10,11,12,13,16,17,18,19,20,21,24,25,26,27,28,29,32,33,34,35,36,37,40,41,42,43,44,45,48,49,50,51,52,53 },
	{  9,10,11,12,13,14,17,18,19,20,21,22,25,26,27,28,29,30,33,34,35,36,37,38,41,42,43,44,45,46,49,50,51,52,53,54 },
	{ 10,11,12,13,14,15,18,19,20,21,22,23,26,27,28,29,30,31,34,35,36,37,38,39,42,43,44,45,46,47,50,51,52,53,54,55 },
	{ 16,17,18,19,20,21,24,25,26,27,28,29,32,33,34,35,36,37,40,41,42,43,44,45,48,49,50,51,52,53,56,57,58,59,60,61 },
	{ 17,18,19,20,21,22,25,26,27,28,29,30,33,34,35,36,37,38,41,42,43,44,45,46,49,50,51,52,53,54,57,58,59,60,61,62 },
	{ 18,19,20,21,22,23,26,27,28,29,30,31,34,35,36,37,38,39,42,43,44,45,46,47,50,51,52,53,54,55,58,59,60,61,62,63 },
	{  0, 1, 2, 3, 4, 5, 6, 8, 9,10,11,12,13,14,16,17,18,19,20,21,22,24,25,26,27,28,29,30,32,33,34,35,36,37,38,40,41,42,43,44,45,46,48,49,50,51,52,53,54 },
	{  1, 2, 3, 4, 5, 6, 7, 9,10,11,12,13,14,15,17,18,19,20,21,22,23,25,26,27,28,29,30,31,33,34,35,36,37,38,39,41,42,43,44,45,46,47,49,50,51,52,53,54,55 },
	{  8, 9,10,11,12,13,14,16,17,18,19,20,21,22,24,25,26,27,28,29,30,32,33,34,35,36,37,38,40,41,42,43,44,45,46,48,49,50,51,52,53,54,56,57,58,59,60,61,62 },
	{  9,10,11,12,13,14,15,17,18,19,20,21,22,23,25,26,27,28,29,30,31,33,34,35,36,37,38,39,41,42,43,44,45,46,47,49,50,51,52,53,54,55,57,58,59,60,61,62,63 },
	{  0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63 } };
	
	private final int mL1Nodes = patterns.length;	// nodes of the middle layer #1 (pattern dependent)
	private final int mL2Nodes = 40;	// the number of nodes of the middle layer #2
	private final int mL3Nodes = 10;	// the number of nodes of the middle layer #3
	private int mSpatialWeights;		// weights of the spatial processing unit (to be calculated)
	
	// the constructors...
	public NN_64_91_40_10_1()
	{
		mColor = OthColors.black;
		mSearchDepth = 1;
		
		mSpatialWeights = 0;
		for(int i = 0; i < mL1Nodes; ++i) mSpatialWeights += patterns[i].length;
		
		mBrain = new double[mSpatialWeights + mL1Nodes + (mL1Nodes + 1)*mL2Nodes + (mL2Nodes + 1)*mL3Nodes + mL3Nodes + 1];

		mMidLayer1Nodes = new double[mL1Nodes];
		mMidLayer2Nodes = new double[mL2Nodes];
		mMidLayer3Nodes = new double[mL3Nodes];
	}

	
	public NN_64_91_40_10_1(int color)
	{
		mColor = color;
		mSearchDepth = 1;
		
		mSpatialWeights = 0;
		for(int i = 0; i < mL1Nodes; ++i) mSpatialWeights += patterns[i].length;
		
		mBrain = new double[mSpatialWeights + mL1Nodes + (mL1Nodes + 1)*mL2Nodes + (mL2Nodes + 1)*mL3Nodes + mL3Nodes + 1];

		mMidLayer1Nodes = new double[mL1Nodes];
		mMidLayer2Nodes = new double[mL2Nodes];
		mMidLayer3Nodes = new double[mL3Nodes];
	}
		
	public NN_64_91_40_10_1(int color, int depth)
	{
		mColor = color;
		setDepth(depth);
		
		mSpatialWeights = 0;
		for(int i = 0; i < mL1Nodes; ++i) mSpatialWeights += patterns[i].length;
		
		mBrain = new double[mSpatialWeights + mL1Nodes + (mL1Nodes + 1)*mL2Nodes + (mL2Nodes + 1)*mL3Nodes + mL3Nodes + 1];

		mMidLayer1Nodes = new double[mL1Nodes];
		mMidLayer2Nodes = new double[mL2Nodes];
		mMidLayer3Nodes = new double[mL3Nodes];
	}
	
	public NN_64_91_40_10_1(int color, int depth, double[] brain)
	{
		mColor = color;
		setDepth(depth);

		mSpatialWeights = 0;
		for(int i = 0; i < mL1Nodes; ++i) mSpatialWeights += patterns[i].length;
		
		mBrain = new double[mSpatialWeights + mL1Nodes + (mL1Nodes + 1)*mL2Nodes + (mL2Nodes + 1)*mL3Nodes + mL3Nodes + 1];

		mMidLayer1Nodes = new double[mL1Nodes];
		mMidLayer2Nodes = new double[mL2Nodes];
		mMidLayer3Nodes = new double[mL3Nodes];
		
		setBrain(brain);
	}
	
	// save Neural Net's weights to disk
	public void saveBrain(String filename)
	{
		PrintWriter writer = null;
		
		try 
		{
			writer = new PrintWriter(filename);
			for(int i = 0; i < mBrain.length; ++i)
			{
				writer.print(mBrain[i] + " ");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrain()\nBrain (" + filename + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}
	
	// load Neural Net's weights from disk
	public void loadBrain(String filename)
	{
		BufferedReader reader = null;
				
		try 
		{
			String line;
			reader = new BufferedReader(new FileReader(filename));
			
			line = reader.readLine();
			line = line.trim();

			String[] weights = line.split("\\s");
			if(weights.length == mBrain.length)
			{
				for(int i = 0; i < mBrain.length; ++i) mBrain[i] = Double.parseDouble(weights[i]);
			}
			else
			{
				System.err.println("ERROR: Neural Net must have exactly " + mBrain.length + " weights");
				System.err.println("but this file contains " + weights.length + " weights");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method loadBrain()\nBrain (" + filename + ") not loaded ...");
		}
		finally
		{
			if(reader != null)
			try 
			{
				reader.close();
			} 
			catch (IOException e)
			{
				// nothing to do here...
			}
		}
	}

	@Override
	public String getScore()
	{
		return String.format("%.4f", mScore);
	}
	
	@Override
	public void setDepth(int depth)
	{
		if(depth < 1) depth = 1;
		else mSearchDepth = depth;
	}
	
	@Override
	public void setBrain(double[] brain)
	{
		// check for the correct number of weights
		if(brain != null && brain.length == mBrain.length)
		{
			// set the new brain weights here ...
			for(int i = 0; i < mBrain.length; ++i)
			{
				mBrain[i] = brain[i];
			}
				
			return;
		}

		System.err.println("ERROR: Neural Net must have exactly " + mBrain.length + " weights");
		System.err.println("Found (" + brain.length + ") weights... Brain not set.");
	}
	
	// position is evaluated from AI's(computer) perspective
	// assuming the Net evaluates from black's perspective
	private double evaluateNode(OthBoard board)
	{
		int[] position = board.getBoard();	// position[i] must have values +1 (B) , 0 (E) , -1 (W)
		
		// reverse board input if AI plays white...
		if(mColor == OthColors.white)
		{
			for(int i = 0; i < 64; ++i) position[i] = -position[i];
		}

		int wx = 0;		// weight and bias indices inside mBrain
		double nSum;	// the sum of values of all the incoming connections to a node
		
		// middle layer #1 calculations ...
		for(int n = 0; n < mL1Nodes; ++n)
		{
			nSum = 0;
			
			for(int w = 0; w < patterns[n].length; ++w)
			{
				nSum += mBrain[wx]*position[patterns[n][w]];
				++wx;
			}

			mMidLayer1Nodes[n] = Math.tanh(nSum + mBrain[wx]);	// sum + bias for node (n)
			++wx;
		}
		
		// middle layer #2 calculations ...
		for(int n = 0; n < mL2Nodes; ++n)
		{
			nSum = 0;
			for(int w = 0; w < mL1Nodes; ++w)
			{
				nSum += mBrain[wx]*mMidLayer1Nodes[w];
				++wx;
			}
			
			mMidLayer2Nodes[n] = Math.tanh(nSum + mBrain[wx]);	// sum + bias for node (n)
			++wx;
		}
		
		// middle layer #3 calculations ...
		for(int n = 0; n < mL3Nodes; ++n)
		{
			nSum = 0;
			for(int w = 0; w < mL2Nodes; ++w)
			{
				nSum += mBrain[wx]*mMidLayer2Nodes[w];
				++wx;
			}
			
			mMidLayer3Nodes[n] = Math.tanh(nSum + mBrain[wx]);	// sum + bias for node (n)
			++wx;
		}
		
		// output layer calculations ...
		nSum = 0;
		for(int node = 0; node < mL3Nodes; ++node)
		{
			nSum += mBrain[wx]*mMidLayer3Nodes[node];
			++wx;
		}

		return Math.tanh(nSum + mBrain[wx]);
	}

	private double AlphaBeta(OthBoard board, int color, int depth, double a, double b)
	{
		OthBoard temp;
		ArrayList<OthMove> candidates;

		// if maximum depth is reached evaluate the position
		if(depth <= 0)
		{
			return evaluateNode(board);
		}
		
		// find all the candidate moves for the current player
		candidates = OthManager.getLegalMoves(board, color);
		if(candidates.isEmpty())
		{
			// find all the candidate moves for his opponent
			color = -color;
			candidates = OthManager.getLegalMoves(board, color);
			// and check to see, if the Game is Over!
			if(candidates.isEmpty())
			{
				// the Game is Over...
				return evaluateNode(board);
			}
			
			// the current player simply passes his turn
			// do nothing here ...
		}
		
		// save a copy of the original board for later use
		// and start alpha-beta search
		temp = new OthBoard(board.getBoard());
		
		// this is the node's score
		double v;
		
		// the AI (computer) is the maximizing player
		if(color == mColor)
		{
			v = MINIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.max(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v > a) a = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// beta cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
		// the AI's opponent is the minimizing player
		else
		{
			v = MAXIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.min(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v < b) b = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());

		        // alpha cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
	}
	
	@Override
	public OthMove nextMove(OthBoard board) 
	{
		ArrayList<OthMove> candidates = OthManager.getLegalMoves(board, mColor);
		if(candidates.isEmpty()) return null;	// no moves available for this position

		double score;
		double a = MINIMUM;
		double b = MAXIMUM;
		OthMove bestMove = null;
		
		// exhaustive search for the last few squares
		//if(board.getDisksOfColor(OthColors.blank) < 15) mSearchDepth = 30;	// this one is never reached :)
		
		// save a copy of the original board for later use
		OthBoard temp = new OthBoard(board.getBoard());

		score = MINIMUM;
		for(OthMove move: candidates)
		{
			// make the move on board
			OthManager.playMove(board, move);

			score = Math.max(score, AlphaBeta(board, -mColor, mSearchDepth-1, a, b));
			
			if(score > a)
			{
				a = score;
				bestMove = move;
				mScore = score;
			}
			
			// restore the original board
			board.setBoard(temp.getBoard());
		}
		
		if(rvalue.nextDouble() < eGreedy) return candidates.get(rvalue.nextInt(candidates.size()));
		return bestMove;
	}
}
