
public abstract class OthAIPlayer extends OthPlayer
{
	public abstract boolean setDepth(int depth);		// sets AI's search depth
	public abstract boolean setBrain(int[] brain);		// sets AI's weights manually (integer values)
	public abstract boolean setBrain(double[] brain);	// sets AI's weights manually (double precision values)
	
	public abstract boolean saveBrain(String filename);	// saves AI's weights to disk
	public abstract boolean loadBrain(String filename);	// loads AI's weights from disk
	
	public abstract String getScore();					// a string representation of the move's score ...
	public abstract void setPerfectEndgame(int depth);	// sets depth, for a perfect end-game play ...
}
