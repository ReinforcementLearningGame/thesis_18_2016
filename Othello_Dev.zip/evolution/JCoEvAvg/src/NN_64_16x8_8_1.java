// this is a weight sharing Neural Network with 64-16x8-8-1 architecture (with biases)
// this network has a total of 1185 weights

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

public class NN_64_16x8_8_1 extends OthAIPlayer
{
	private int mSearchDepth;			// maximum search depth of AI

	private final int mL1SSets = 16;	// the number of symmetry sets of the middle layer #1
	private final int mL2Nodes =  8;	// the number of nodes of the middle layer #2
	
	private double mScore;				// the score of the move played by AI
	private double[] mBrain;
	private double[][] mMidLayer1Nodes;	// the value of each node of the middle layer #1
	private double[]   mMidLayer2Nodes;	// the value of each node of the middle layer #2
	
	private final double MAXIMUM = +2;
	private final double MINIMUM = -2;

	private final double eGreedy = 0.0;		// performs random moves from time to time...
	private final Random rvalue = new Random();
	
	// symmetry transformation matrices for all 8 symmetries.
	// The i symmetric of a square s is the square symmetric[i][s] i = 0,1,2...7 , s = 0,1,2...63	
	private int[][] symmetric = {
			
	{  0,  1,  2,  3,  4,  5,  6,  7,  
	   8,  9, 10, 11, 12, 13, 14, 15, 
	  16, 17, 18, 19, 20, 21, 22, 23, 
	  24, 25, 26, 27, 28, 29, 30, 31,
	  32, 33, 34, 35, 36, 37, 38, 39, 
	  40, 41, 42, 43, 44, 45, 46, 47, 
	  48, 49, 50, 51, 52, 53, 54, 55, 
	  56, 57, 58, 59, 60, 61, 62, 63 },
		
	{  0,  8, 16, 24, 32, 40, 48, 56, 
	   1,  9, 17, 25, 33, 41, 49, 57, 
	   2, 10, 18, 26, 34, 42, 50, 58, 
	   3, 11, 19, 27, 35, 43, 51, 59,
	   4, 12, 20, 28, 36, 44, 52, 60, 
	   5, 13, 21, 29, 37, 45, 53, 61, 
	   6, 14, 22, 30, 38, 46, 54, 62, 
	   7, 15, 23, 31, 39, 47, 55, 63 },

	{ 56, 48, 40, 32, 24, 16,  8, 0, 
	  57, 49, 41, 33, 25, 17,  9, 1, 
	  58, 50, 42, 34, 26, 18, 10, 2, 
	  59, 51, 43, 35, 27, 19, 11, 3,
	  60, 52, 44, 36, 28, 20, 12, 4, 
	  61, 53, 45, 37, 29, 21, 13, 5, 
	  62, 54, 46, 38, 30, 22, 14, 6, 
	  63, 55, 47, 39, 31, 23, 15, 7  },
		
	{  7,  6,  5,  4,  3,  2,  1,  0, 
	  15, 14, 13, 12, 11, 10,  9,  8, 
	  23, 22, 21, 20, 19, 18, 17, 16, 
	  31, 30, 29, 28, 27, 26, 25, 24,
	  39, 38, 37, 36, 35, 34, 33, 32, 
	  47, 46, 45, 44, 43, 42, 41, 40, 
	  55, 54, 53, 52, 51, 50, 49, 48, 
	  63, 62, 61, 60, 59, 58, 57, 56 },
				
	{ 63, 62, 61, 60, 59, 58, 57, 56, 
	  55, 54, 53, 52, 51, 50, 49, 48, 
	  47, 46, 45, 44, 43, 42, 41, 40, 
	  39, 38, 37, 36, 35, 34, 33, 32,
	  31, 30, 29, 28, 27, 26, 25, 24, 
	  23, 22, 21, 20, 19, 18, 17, 16, 
	  15, 14, 13, 12, 11, 10,  9,  8,  
	   7,  6,  5,  4,  3,  2,  1,  0 },

	{ 63, 55, 47, 39, 31, 23, 15, 7, 
	  62, 54, 46, 38, 30, 22, 14, 6, 
	  61, 53, 45, 37, 29, 21, 13, 5, 
	  60, 52, 44, 36, 28, 20, 12, 4,
	  59, 51, 43, 35, 27, 19, 11, 3, 
	  58, 50, 42, 34, 26, 18, 10, 2, 
	  57, 49, 41, 33, 25, 17,  9, 1, 
	  56, 48, 40, 32, 24, 16,  8, 0  },
		
	{  7, 15, 23, 31, 39, 47, 55, 63, 
	   6, 14, 22, 30, 38, 46, 54, 62, 
	   5, 13, 21, 29, 37, 45, 53, 61, 
	   4, 12, 20, 28, 36, 44, 52, 60,
	   3, 11, 19, 27, 35, 43, 51, 59, 
	   2, 10, 18, 26, 34, 42, 50, 58, 
	   1,  9, 17, 25, 33, 41, 49, 57, 
	   0,  8, 16, 24, 32, 40, 48, 56 },
		
	{ 56, 57, 58, 59, 60, 61, 62, 63, 
	  48, 49, 50, 51, 52, 53, 54, 55, 
	  40, 41, 42, 43, 44, 45, 46, 47, 
	  32, 33, 34, 35, 36, 37, 38, 39,
	  24, 25, 26, 27, 28, 29, 30, 31, 
	  16, 17, 18, 19, 20, 21, 22, 23, 
	   8,  9, 10, 11, 12, 13, 14, 15,  
	   0,  1,  2,  3,  4,  5,  6,  7 } };
	
	// the constructors...
	public NN_64_16x8_8_1()
	{
		mColor = OthColors.black;
		mSearchDepth = 1;
		
		mBrain = new double[65*mL1SSets + (mL1SSets + 1)*mL2Nodes + mL2Nodes + 1];

		mMidLayer1Nodes = new double[mL1SSets][8];
		mMidLayer2Nodes = new double[mL2Nodes];
	}

	
	public NN_64_16x8_8_1(int color)
	{
		mColor = color;
		mSearchDepth = 1;
		
		mBrain = new double[65*mL1SSets + (mL1SSets + 1)*mL2Nodes + mL2Nodes + 1];
		
		mMidLayer1Nodes = new double[mL1SSets][8];
		mMidLayer2Nodes = new double[mL2Nodes];
	}
		
	public NN_64_16x8_8_1(int color, int depth)
	{
		mColor = color;
		setDepth(depth);
		
		mBrain = new double[65*mL1SSets + (mL1SSets + 1)*mL2Nodes + mL2Nodes + 1];
		
		mMidLayer1Nodes = new double[mL1SSets][8];
		mMidLayer2Nodes = new double[mL2Nodes];
	}
	
	public NN_64_16x8_8_1(int color, int depth, double[] brain)
	{
		mColor = color;
		setDepth(depth);

		mBrain = new double[65*mL1SSets + (mL1SSets + 1)*mL2Nodes + mL2Nodes + 1];
		
		mMidLayer1Nodes = new double[mL1SSets][8];
		mMidLayer2Nodes = new double[mL2Nodes];
		
		setBrain(brain);
	}
	
	// save Neural Net's weights to disk
	public void saveBrain(String filename)
	{
		PrintWriter writer = null;
		
		try 
		{
			writer = new PrintWriter(filename);
			for(int i = 0; i < mBrain.length; ++i)
			{
				writer.print(mBrain[i] + " ");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrain()\nBrain (" + filename + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}
	
	// load Neural Net's weights from disk
	public void loadBrain(String filename)
	{
		BufferedReader reader = null;
				
		try 
		{
			String line;
			reader = new BufferedReader(new FileReader(filename));
			
			line = reader.readLine();
			line = line.trim();

			String[] weights = line.split("\\s");
			if(weights.length == mBrain.length)
			{
				for(int i = 0; i < mBrain.length; ++i) mBrain[i] = Double.parseDouble(weights[i]);
			}
			else
			{
				System.err.println("ERROR: Neural Net must have exactly " + mBrain.length + " weights");
				System.err.println("but this file contains " + weights.length + " weights");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method loadBrain()\nBrain (" + filename + ") not loaded ...");
		}
		finally
		{
			if(reader != null)
			try 
			{
				reader.close();
			} 
			catch (IOException e)
			{
				// nothing to do here...
			}
		}
	}

	@Override
	public String getScore()
	{
		return String.format("%.4f", mScore);
	}
	
	@Override
	public void setDepth(int depth)
	{
		if(depth < 1) depth = 1;
		else mSearchDepth = depth;
	}
	
	@Override
	public void setBrain(double[] brain)
	{
		// check for the correct number of weights
		if(brain != null && brain.length == mBrain.length)
		{
			// set the new brain weights here ...
			for(int i = 0; i < mBrain.length; ++i)
			{
				mBrain[i] = brain[i];
			}
				
			return;
		}

		System.err.println("ERROR: Neural Net must have exactly " + mBrain.length + " weights");
		System.err.println("Found (" + brain.length + ") weights... Brain not set.");
	}
	
	// position is evaluated from AI's(computer) perspective
	// assuming the Net evaluates from black's perspective
	private double evaluateNode(OthBoard board)
	{
		int[] position = board.getBoard();	// position[i] must have values +1 (Black) , 0 (Empty) , -1 (White)
		
		// reverse board input if AI plays white...
		if(mColor == OthColors.white)
		{
			for(int i = 0; i < 64; ++i) position[i] = -position[i];
		}
		
		int wx = 0;	// weight indices inside mBrain
		int bx;		// bias indices inside mBrain
		
		double nSum;	// the sum of values of all the incoming connections to a node
		
		// middle layer #1 calculations ...
		for(int s = 0; s < mL1SSets; ++s)
		{
			bx = 65*s;
			
			for(int n = 0; n < 8; ++n)
			{
				wx = bx;
				nSum = 0;
				
				for(int inp = 0; inp < 64; ++inp)
				{
					nSum += mBrain[wx]*position[symmetric[n][inp]];
					++wx;
				}

				mMidLayer1Nodes[s][n] = Math.tanh(nSum + mBrain[wx]);
			}
		}
		
		// middle layer #2 calculations ...
		++wx;
		
		for(int node = 0; node < mL2Nodes; ++node)
		{
			nSum = 0;
			
			for(int s = 0; s < mL1SSets; ++s)
			{
				for(int n = 0; n < 8; ++n)
				{
					nSum += mBrain[wx]*mMidLayer1Nodes[s][n];
				}
				
				++wx;
			}
			
			mMidLayer2Nodes[node] = Math.tanh(nSum + mBrain[wx]);
			++wx;
		}
		
		// output layer calculations ...
		nSum = 0;
		
		for(int node = 0; node < mL2Nodes; ++node)
		{
			nSum += mBrain[wx]*mMidLayer2Nodes[node];
			++wx;
		}

		return Math.tanh(nSum + mBrain[wx]);
	}

	private double AlphaBeta(OthBoard board, int color, int depth, double a, double b)
	{
		OthBoard temp;
		ArrayList<OthMove> candidates;

		// if maximum depth is reached evaluate the position
		if(depth <= 0)
		{
			return evaluateNode(board);
		}
		
		// find all the candidate moves for the current player
		candidates = OthManager.getLegalMoves(board, color);
		if(candidates.isEmpty())
		{
			// find all the candidate moves for his opponent
			color = -color;
			candidates = OthManager.getLegalMoves(board, color);
			// and check to see, if the Game is Over!
			if(candidates.isEmpty())
			{
				// the Game is Over...
				return evaluateNode(board);
			}
			
			// the current player simply passes his turn
			// do nothing here ...
		}
		
		// save a copy of the original board for later use
		// and start alpha-beta search
		temp = new OthBoard(board.getBoard());
		
		// this is the node's score
		double v;
		
		// the AI (computer) is the maximizing player
		if(color == mColor)
		{
			v = MINIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.max(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v > a) a = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// beta cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
		// the AI's opponent is the minimizing player
		else
		{
			v = MAXIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.min(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v < b) b = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());

		        // alpha cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
	}
	
	@Override
	public OthMove nextMove(OthBoard board) 
	{
		ArrayList<OthMove> candidates = OthManager.getLegalMoves(board, mColor);
		if(candidates.isEmpty()) return null;	// no moves available for this position

		double score;
		double a = MINIMUM;
		double b = MAXIMUM;
		OthMove bestMove = null;
		
		// exhaustive search for the last few squares
		//if(board.getDisksOfColor(OthColors.blank) < 15) mSearchDepth = 30;	// this one is never reached :)
		
		// save a copy of the original board for later use
		OthBoard temp = new OthBoard(board.getBoard());

		score = MINIMUM;
		for(OthMove move: candidates)
		{
			// make the move on board
			OthManager.playMove(board, move);

			score = Math.max(score, AlphaBeta(board, -mColor, mSearchDepth-1, a, b));
			
			if(score > a)
			{
				a = score;
				bestMove = move;
				mScore = score;
			}
			
			// restore the original board
			board.setBoard(temp.getBoard());
		}
		
		if(rvalue.nextDouble() < eGreedy) return candidates.get(rvalue.nextInt(candidates.size()));
		return bestMove;
	}
}
