package com.vasmakk.othello;

import android.app.Activity;
import android.os.Bundle;

public class ActivityLaunch extends Activity
{
	GameScreen screen;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		screen = new GameScreen(this);
		setContentView(screen);
	}

	@Override
	protected void onDestroy() 
	{
		screen.destroy();
		super.onDestroy();
	}
}
