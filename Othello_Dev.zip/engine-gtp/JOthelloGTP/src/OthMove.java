
public class OthMove 
{
	private int mSquare;
	private int mColor;
	
	// the constructor
	public OthMove(int square, int color)
	{
		mSquare = square;
		mColor = color;
	}

	// getters...
	public int getSquare()
	{
		return mSquare;
	}
	
	public int getColor()
	{
		return mColor;
	}

}
