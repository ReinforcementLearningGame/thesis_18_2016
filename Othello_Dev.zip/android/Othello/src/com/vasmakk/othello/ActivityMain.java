package com.vasmakk.othello;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

public class ActivityMain extends Activity implements OnClickListener
{
	Button btnGame, btnOptions, btnRules, btnCredits;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);        
        setContentView(R.layout.activity_main);
        
        btnGame = (Button) findViewById(R.id.btn_new_game);
        btnRules = (Button) findViewById(R.id.btn_game_rules);
        btnOptions = (Button) findViewById(R.id.btn_options);
        btnCredits = (Button) findViewById(R.id.btn_credits);
        
        btnGame.setOnClickListener(this);
        btnRules.setOnClickListener(this);
        btnOptions.setOnClickListener(this);
        btnCredits.setOnClickListener(this);
    }

	@Override
	public void onClick(View v) 
	{
		int id = v.getId();
		
		switch(id)
		{
			case R.id.btn_new_game:
				startActivity(new Intent(ActivityMain.this, ActivityLaunch.class));
				break;
				
			case R.id.btn_options:
				startActivity(new Intent(ActivityMain.this, ActivityOptions.class));
				break;
				
			case R.id.btn_game_rules:
				startActivity(new Intent(ActivityMain.this, ActivityRules.class));
				break;
				
			case R.id.btn_credits:
				credits().show();
				break;
		}
	}

	private AlertDialog credits()
	{
		AlertDialog dialog = new AlertDialog.Builder(this).create();
		
		CharSequence dgTitle = getResources().getText(R.string.txt_credits_title);
		CharSequence message = getResources().getText(R.string.txt_credits_body);
		
		ScrollView sview = new ScrollView(this);
		TextView tview = new TextView(this);
		
		tview.setText(message);
		tview.setGravity(Gravity.CENTER);
		tview.setTextSize(getResources().getDimension(R.dimen.text_dialog));
		sview.addView(tview);
		
		dialog.setTitle(dgTitle);
		dialog.setView(sview);
		dialog.setCancelable(false);
		
		dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Got It!", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which) 
			{
				// release resources ...
				dialog.dismiss();
			}
		});
		
		return dialog;
	}
	
	
}
