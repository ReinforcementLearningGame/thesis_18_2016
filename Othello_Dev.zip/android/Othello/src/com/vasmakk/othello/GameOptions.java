package com.vasmakk.othello;

public class GameOptions 
{
	static final String[] personalities =
	{
		"2h Net Gen.3376 Hikaru",
		"2h Net Gen.3538 Vincent",
		"3h Net Gen.2468 Sonya",
		"3h Net Gen.2541 Valerie",
		"3h Net Gen.3026 Jessica",
		"3h Net Gen.3951 Dr. Roth",
		"Std Ev Function Mr. Simmons"
	};
	
	static final String[] personalityTypes =
	{
		"64-16x8-8-1",
		"64-16x8-8-1",
		"64-16x8-8-4-1",
		"64-16x8-8-4-1",
		"64-16x8-8-4-1",
		"64-16x8-8-4-1",
		"AI-Standard"
	};
	
	static final String[] personalityFiles =
	{
		"2h_10_60_3376",
		"2h_10_60_3538",
		"3h_10_70_2468",
		"3h_10_70_2541",
		"3h_10_70_3026",
		"3h_10_70_3951",
		"ai_std_ev_710"
	};
	
	static final String[] midgameSearchDepth =
	{
		"1", "2", "3", "4", "5", "6", "7", "8"
	};
	
	static final String[] endgameSearchDepth = 
	{
		"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"
	};
	

	
	static String personalityType = personalityTypes[0];
	static String personalityFile = personalityFiles[0];
	
	static int aiColor = AndOthColors.white;
	
	static int personalitiesIndex = 0;
	static int midgameSearchIndex = 0;
	static int endgameSearchIndex = 0;
	
	static boolean openingBook = false;
	static boolean soundEffects = false;
}
