public class JOthelloGTP 
{
	public static void main(String[] arg)
	{
		String configFile = "noFile";
		
		if(arg != null && arg.length == 1) configFile = arg[0];
		new Gtp(configFile);
	}
}
