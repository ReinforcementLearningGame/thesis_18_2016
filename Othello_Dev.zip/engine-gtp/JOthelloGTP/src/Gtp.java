import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Gtp 
{	
	private String AI_NAME		= "V-Othello (original) depth's = 0";
	private String AI_VERSION	= "1.0";
	private String PROTOCOL_VERSION	= "2";
	private String MOVE_SEQUENCE	= "";
	
	OthBoard board = null;
	OthMove 	mv = null;
	OthBook		bk = null;
	OthAIPlayer ai = null;

	private boolean IN_PANIC_MODE;
	private boolean QUIT_GTP_LOOP;
	private boolean COMMAND_HASID;
	private  String COMMAND_IDVAL; 

	private String[] commands = 
	{
		"protocol_version",
		"name",
		"version",
		"known_command",
		"list_commands",
		"quit",
		"showboard",
		"boardsize",
		"clear_board",
		"komi",
		"play",
		"genmove",
		"time_settings",
		"time_left",
		"set_game",
		"list_games"
	};
	
	// the constructor ...
	public Gtp(String configFile)
	{
		IN_PANIC_MODE = false;
		COMMAND_HASID = false;
		QUIT_GTP_LOOP = false;
		
		loadParameters(configFile);		// load AI's parameters from file
				
		startMessageLoop();
	}
	
	// start the message loop ...
	private void startMessageLoop()
	{		
		BufferedReader stream;
		String line;
		
		try 
		{
			stream = new BufferedReader(new InputStreamReader(System.in));
			
			while((line = stream.readLine()) != null)
			{
				if(IN_PANIC_MODE)
				{
					// parameters not loaded correctly ...
					sendPanicMessage();
					break;
				}
				
				// replace CR with SPACE
				line = line.replace((char) 13, (char)32);
				
				// replace TAB with SPACE
				line = line.replace((char)  9, (char)32);
				
				// replace other control characters with SPACE
				line = line.replace((char)127, (char)32);
				for(char ch = 1; ch < 32; ++ch)
				{
					if(ch == (char) 10) continue;		// skip LF characters
					line = line.replace(ch, (char)32);
				}
				
				// remove whitespace
				line = line.trim();
				
				// discard comments or empty lines
				if(line.startsWith("#") || line.isEmpty()) continue;

				// after all this preparation, start processing 
				processCommand(line);
				
				if(QUIT_GTP_LOOP) break;
			}
			
			stream.close();
		}
		catch(IOException ioe)
		{
			// nothing to do here ...
		}
	}
	
	private void processCommand(String command)
	{
		int i;
		String[] token = command.split("\\s");
		
		// check if the first argument is command's ID
		if(token[0].matches("\\d+"))
		{
			COMMAND_HASID = true;
		}
		else 
		{
			COMMAND_HASID = false;
		}
		
		// and if the command has it, we take its value
		if(COMMAND_HASID)
		{
			COMMAND_IDVAL = token[0];
			i = 1;
		}
		else
		{
			COMMAND_IDVAL = "";
			i = 0;
		}
		
		if(token[i].equals("protocol_version"))
		{
			sendSuccessMessage(PROTOCOL_VERSION);
		}
		else
		if(token[i].equals("name"))
		{
			sendSuccessMessage(AI_NAME);
		}
		else
		if(token[i].equals("version"))
		{
			sendSuccessMessage(AI_VERSION);
		}
		else
		if(token[i].equals("known_command"))
		{
			if(token.length != i + 2)
				sendSuccessMessage("false");
			else
				sendSuccessMessage(isKnownCommand(token[i + 1]));
		}
		else
		if(token[i].equals("list_commands"))
		{
			sendSuccessMessage(getCommandList());
		}
		else
		if(token[i].equals("showboard"))
		{
			sendSuccessMessage(getBoardView(board));
		}
		else
		if(token[i].equals("boardsize"))
		{
			if(token.length != i + 2 || !token[i + 1].matches("\\d+"))
				sendFailureMessage("syntax error");
			else
			if(!token[i + 1].equals("8"))
				sendFailureMessage("unacceptable size");
			else
			{
				sendSuccessMessage("");
				board.reset();		// reset board to the starting position
				MOVE_SEQUENCE = "";	// clear the moves list
			}
		}
		else
		if(token[i].equals("clear_board"))
		{
			sendSuccessMessage("");
			board.reset();		// reset board to the starting position
			MOVE_SEQUENCE = "";	// clear the moves list
		}
		else
		if(token[i].equals("komi"))
		{
			if(token.length != i + 2 || !token[i + 1].matches("[+-]?\\d*(\\.\\d+)?"))
				sendFailureMessage("syntax error");
			else
				sendSuccessMessage("");
		}
		else
		if(token[i].equals("play"))
		{
			if(token.length != i + 3)
				sendFailureMessage("syntax error");
			else
			{
				int colour = getColour(token[i + 1]);
				int square = getSquare(token[i + 2]);
				
				if(OthManager.isALegalMove(board, square, colour))
				{
					// player plays his move
					OthManager.playMove(board, new OthMove(square, colour));
					
					// add this move to the moves list
					MOVE_SEQUENCE += token[i + 2];
					
					// and send a success message
					sendSuccessMessage("");
				}
				else
				{
					// this is an illegal move
					sendFailureMessage("illegal move");
				}
			}
		}
		else
		if(token[i].equals("genmove"))
		{
			if(token.length != i + 2)
				sendFailureMessage("syntax error");
			else
			{
				int colour = getColour(token[i + 1]);
				String move;

				if(OthManager.getLegalMoves(board, colour) == null)
				{
					// AI just passes
					sendSuccessMessage("pass");
				}
				else
				{
					// AI plays his move
					ai.setColor(colour);
					
					// get a valid reply from the opening book... if exists!
					move = bk.reply(MOVE_SEQUENCE);
					
					if(move.isEmpty())
					{
						mv = ai.nextMove(board);
						move = OthManager.getSquareLabel(mv.getSquare());
						
						// AI plays its move
						OthManager.playMove(board, mv);
					}
					else
					{
						// AI plays its move
						OthManager.playMove(board, new OthMove(OthManager.getSquareValue(move), colour));
					}

					// add this move to the moves list
					MOVE_SEQUENCE += move;
					
					// and send a success message
					sendSuccessMessage(move);
				}
			}
		}
		else
		if(token[i].equals("time_settings"))
		{
			// unimplemented
			sendSuccessMessage("");
		}
		else
		if(token[i].equals("time_left"))
		{
			// unimplemented
			sendSuccessMessage("");
		}
		else
		if(token[i].equals("set_game"))
		{
			if(token.length != i + 2 || !token[i + 1].equals("Othello"))
				sendFailureMessage("unsupported game");
			else
				sendSuccessMessage("");
		}
		else
		if(token[i].equals("list_games"))
		{
			sendSuccessMessage("Othello");
		}
		else
		if(token[i].equals("quit"))
		{
			sendSuccessMessage("");
			QUIT_GTP_LOOP = true;
		}
		else
		{
			sendFailureMessage("unknown command");
		}
		
	}
	
	private String isKnownCommand(String command)
	{
		for(int i = 0; i < commands.length; ++i)
		{
			if(commands[i].equals(command)) return "true";
		}
		
		return "false";
	}
	
	private String getCommandList()
	{
		String list = "";
		
		for(int i = 0; i < commands.length; ++i)
		{
			list += commands[i] + "\n";
		}
		
		return list.trim();
	}
	
	private void sendSuccessMessage(String message)
	{
		String separator;
		
		if(message.isEmpty()) separator = ""; else separator = " ";
		System.out.print("=" + COMMAND_IDVAL + separator + message + "\n\n");
		System.out.flush();
	}
	
	private void sendFailureMessage(String message)
	{
		String separator;
		
		if(message.isEmpty()) separator = ""; else separator = " ";
		System.out.print("?" + COMMAND_IDVAL + separator + message + "\n\n");
		System.out.flush();
	}
	
	private String getBoardView(OthBoard board)
	{
		int index = 0;
		String sBoard = "\n";
		
		for(int i = 0; i < 8; ++i) sBoard += " " + (char)('a' + i) + " ";
		sBoard += "\n";
		
		for(int i = 0; i < 8; ++i)
		{
			for(int j = 0; j < 8; ++j)
			{
				if(board.getSquareColor(index) == OthColors.blank) sBoard += " - ";
				if(board.getSquareColor(index) == OthColors.black) sBoard += " X ";
				if(board.getSquareColor(index) == OthColors.white) sBoard += " O ";
				++index;
			}
			
			sBoard += (i + 1) + "\n";
		}
		
		return sBoard;
	}
	
	private int getColour(String player)
	{
		if(player.equals("w") || player.equals("white")) return OthColors.white;
		if(player.equals("b") || player.equals("black")) return OthColors.black;
		return 0;
	}
	
	private int getSquare(String square)
	{
		return OthManager.getSquareValue(square);
	}
	
	private void loadParameters(String configFile)
	{
		String[] aiName = null;
		String[] aiVers	= null;
		String[] aiType = null;
		String[] sDepth = null;
		String[] eDepth = null;
		String[] aiData = null;
		
		// first of all, create the Othello board
		board = new OthBoard();
		
		// and load opening book if exists
		bk = new OthBook("openings");
		
		// read configuration parameters from file
		try 
		{
			BufferedReader reader = new BufferedReader(new FileReader(configFile));

			aiName = reader.readLine().split("=");
			aiVers = reader.readLine().split("=");
			aiType = reader.readLine().split("=");
			sDepth = reader.readLine().split("=");
			eDepth = reader.readLine().split("=");
			aiData = reader.readLine().split("=");

			reader.close();
			
			aiName[1] = aiName[1].trim();
			aiVers[1] = aiVers[1].trim();
			aiType[1] = aiType[1].trim();
			sDepth[1] = sDepth[1].trim();
			eDepth[1] = eDepth[1].trim();
			aiData[1] = aiData[1].trim();
		}
		catch (IOException io)
		{
			System.err.println("USING DEFAULT AI MODE ...");
			// if there is no configuration file
			// a default Fixed Evaluation Function AI is chosen
			ai = new AI_Standard_Ev();
			return;
		}
		
		// Set the new name for AI
		AI_NAME = aiName[1];
		
		// And the new version
		AI_VERSION = aiVers[1];
		
		// create the AI
		if(aiType[1].equalsIgnoreCase("64-16x8-8-1")) ai = new AI_64_16x8_8_1();
		else
		if(aiType[1].equalsIgnoreCase("64-16x8-8-4-1")) ai = new AI_64_16x8_8_4_1();
		else
		if(aiType[1].equalsIgnoreCase("AI-Standard")) ai = new AI_Standard_Ev();
		else
		{
			IN_PANIC_MODE = true;
			return;
		}

		// set AI's search depth
		try
		{
			ai.setDepth(Integer.parseInt(sDepth[1]));
		}
		catch(NumberFormatException e)
		{
			IN_PANIC_MODE = true;
			return;
		}
		
		// set AI's end-game search depth
		try
		{
			ai.setPerfectEndgame(Integer.parseInt(eDepth[1]));
		}
		catch(NumberFormatException e)
		{
			IN_PANIC_MODE = true;
			return;
		}
		
		// load AI's weights
		if(!ai.loadBrain(aiData[1]))
		{
			IN_PANIC_MODE = true;
			return;
		}

	}
	
	private void sendPanicMessage()
	{
		System.out.println("# Somebody Help Me, I am in PANIC ..\n\n");
		System.out.flush();
	}
}
