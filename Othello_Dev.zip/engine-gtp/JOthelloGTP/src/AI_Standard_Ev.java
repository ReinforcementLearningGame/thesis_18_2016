import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;


public class AI_Standard_Ev extends OthAIPlayer
{
	private int mSearchDepth = 0;	// maximum search depth of AI (passes are not counted)
	private int mEndgamePlay = 0;	// search depth for perfect end-game play
	
	private int mScore;				// the score of the move played by AI
	private boolean[] mStableSquare;
	
	private final int MAXIMUM = Integer.MAX_VALUE;
	private final int MINIMUM = Integer.MIN_VALUE;
	
	// The positional values of the squares in Othello are shown next:
	// a0 -  -  -  -  -  -  -
	// a1 a2 -  -  -  -  -  -	The values of the squares left are
	// a3 a4 a5 -  -  -  -  -	symmetric to the values shown here
	// a6 a7 a8 a9 -  -  -  -	so there is no reason to repeat...
	// -  -  -  -  -  -  -  -
	// -  -  -  -  -  -  -  -	The "brain" of our Othello program
	// -  -  -  -  -  -  -  -	has the form: { a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, mobility, mobQuality }
	// -  -  -  -  -  -  -  -	as the following matrix shows.
	
	private int mBrain[] = { 1000, -60, -160, -16, -46, -2, 14, -36, -10, 6, 72, 4 };
	
	// Evaluation Table. The positional values of a square (s) is brain[EV[s]].
	private static final int EV[]
	= {  0 , 1 , 3 , 6 , 6 , 3 , 1 , 0 ,
		 1 , 2 , 4 , 7 , 7 , 4 , 2 , 1 ,
		 3 , 4 , 5 , 8 , 8 , 5 , 4 , 3 ,
		 6 , 7 , 8 , 9 , 9 , 8 , 7 , 6 ,
		 6 , 7 , 8 , 9 , 9 , 8 , 7 , 6 ,
		 3 , 4 , 5 , 8 , 8 , 5 , 4 , 3 ,
	     1 , 2 , 4 , 7 , 7 , 4 , 2 , 1 ,
		 0 , 1 , 3 , 6 , 6 , 3 , 1 , 0 } ;


	// This Table is used for the Cyclic Swapping of the board
	private static final int Cyclic[]
	= {   0 ,  7 , 63 , 56 ,  8 ,  1 ,  6 ,  15 ,
		 55 , 62 , 57 , 48 , 16 ,  2 ,  5 ,  23 ,
		 47 , 61 , 58 , 40 , 24 ,  3 ,  4 ,  31 ,
		 39 , 60 , 59 , 32 ,  9 , 14 , 54 ,  49 ,
		 17 , 10 , 13 , 22 , 46 , 53 , 50 ,  41 ,
		 25 , 11 , 12 , 30 , 38 , 52 , 51 ,  33 ,
		 18 , 21 , 45 , 42 , 26 , 19 , 20 ,  29 ,
		 37 , 44 , 43 , 34 , 27 , 28 , 36 ,  35 } ;
	
	public AI_Standard_Ev()
	{
		mColor = OthColors.black;
		mStableSquare = new boolean[64];	// initializes stability values to false
	}
	
	public AI_Standard_Ev(int color)
	{
		mColor = color;
		mStableSquare = new boolean[64];	// initializes stability values to false
	}
	
	@Override
	public boolean saveBrain(String filename)
	{
		PrintWriter writer = null;
		boolean taskCompleted = true;
		
		try 
		{
			writer = new PrintWriter(filename);
			for(int i = 0; i < mBrain.length; ++i)
			{
				writer.print(mBrain[i] + " ");
			}
		}
		catch (IOException e)
		{
			// Brain not saved ...
			taskCompleted = false;
		}
		finally
		{
			if(writer != null) writer.close();
		}
		
		return taskCompleted;
	}
	
	@Override
	public boolean loadBrain(String filename)
	{
		BufferedReader reader = null;
		boolean taskCompleted = true;
				
		try 
		{
			String line;
			reader = new BufferedReader(new FileReader(filename));
			
			line = reader.readLine();
			line = line.trim();

			String[] weights = line.split("\\s");
			if(weights.length == mBrain.length)
			{
				for(int i = 0; i < mBrain.length; ++i) mBrain[i] = Integer.parseInt(weights[i]);
			}
			else
			{
				// weights don't match, Brain not loaded
				taskCompleted = false;
			}
		}
		catch (IOException e)
		{
			// an exception occurred, Brain not loaded
			taskCompleted = false;
		}
		finally
		{
			if(reader != null)
			try 
			{
				reader.close();
			} 
			catch (IOException e)
			{
				// nothing to do here...
			}
		}
		
		return taskCompleted;
	}

	@Override
	public String getScore()
	{
		return String.valueOf(mScore);
	}
	
	@Override
	public boolean setDepth(int depth)
	{
		if(depth < 0) return false;
		
		mSearchDepth = depth;
		return true;
	}
	
	@Override
	public boolean setBrain(int[] brain)
	{
		// check for the correct number of weights
		if(brain != null && brain.length == mBrain.length)
		{
			// set the new brain weights here ...
			for(int i = 0; i < mBrain.length; ++i)
			{
				mBrain[i] = brain[i];
			}
				
			return true;
		}

		// weights don't match, Brain not set
		return false;
	}
	
	@Override
	public boolean setBrain(double[] brain)
	{
		// weights shouldn't be doubles for this AI, Brain not set
		return false;
	}
	
	// this is called when the Game is Over
	// position is evaluated from AI's(computer) perspective ...
	private int evaluateLeaf(OthBoard board)
	{
		int score = mBrain[0]*(board.getDisksOfColor(OthColors.black) - board.getDisksOfColor(OthColors.white));
		
		if(mColor == OthColors.white) return -score;
		return score;
	}
	
	// this is called when depth is exhausted
	// position is evaluated from AI's(computer) perspective ...
	private int evaluateNode(OthBoard board)	
	{
		// for positional calculation...
		int positional = 0;
		
		// for mobility calculation...
		int blackMoves = 0;			// number of black's legal moves
		int whiteMoves = 0;			// number of white's legal moves
		int blacksBest = MINIMUM;	// The score of black's best positional legal move
		int whitesBest = MINIMUM;	// The score of white's best positional legal move
		
		int sq;
		for (int square = 0; square < 64; ++square)
		{
			sq = Cyclic[square];
			
			if(board.getSquareColor(sq) == OthColors.black)
			{
				positional += squareValue(board, sq, OthColors.black);
			}
			else
			if(board.getSquareColor(sq) == OthColors.white)
			{
				positional -= squareValue(board, sq, OthColors.white);
			}
			else
			{
				if(OthManager.isALegalMove(board, sq, OthColors.black))
				{
					++blackMoves;
					if(mBrain[EV[sq]] > blacksBest) blacksBest = mBrain[EV[sq]];
				}	
				
				if(OthManager.isALegalMove(board, sq, OthColors.white))
				{
					++whiteMoves;
					if(mBrain[EV[sq]] > whitesBest) whitesBest = mBrain[EV[sq]];
				}	
			}
		}
		
		if(blacksBest == MINIMUM) blacksBest = 0;
		if(whitesBest == MINIMUM) whitesBest = 0;
		
		int mobility;

		if(blackMoves == whiteMoves)
			mobility = 0;
		else
			mobility = mBrain[10]*(blackMoves - whiteMoves)/(blackMoves + whiteMoves);
		
		// The quality of mobility is defined as follows
		int mQuality = mBrain[11]*(blacksBest - whitesBest);
		
		// Effective mobility. That means mobility with some extra "bonuses"
		int efMobility = mobility + mQuality;
		
		// restore stability values
		for(int square = 0; square < 64; ++square)
		{
			mStableSquare[square] = false;
		}
		
		// return the evaluation...
		if(mColor == OthColors.white) return -positional - efMobility;
		return positional + efMobility;
	}
	
	private int squareValue(OthBoard board, int square, int color)
	{
		int Sa , Sb;		// traverse squares in opposite directions
		boolean Xa , Xb;	// partial stabilities for the square (square) for two opposite directions.
		
		int stabilityValue = 0;
	
		
		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.L[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.R[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getSquareColor(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.L[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getSquareColor(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.R[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------
		  
		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.UL[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.DR[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getSquareColor(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.UL[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getSquareColor(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.DR[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------

		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.U[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.D[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getSquareColor(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.U[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getSquareColor(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.D[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------

		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.UR[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.DL[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getSquareColor(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getSquareColor(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.UR[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getSquareColor(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.DL[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// if the disk in (square) is absolutely stable, it achieves the maximum value
		if(stabilityValue == 4) 
		{
			mStableSquare[square] = true; 
			return mBrain[0]; 
		}

		// when a corner is occupied, its adjacent squares are unimportant for both players
		if (square ==  1 || square ==  8 || square ==  9)
		{
			if(board.getSquareColor(0) != OthColors.blank) return 0;
		}
		  
		if (square ==  6 || square == 14 || square == 15)
		{
			if(board.getSquareColor(7) != OthColors.blank) return 0;
		}
		  
		if (square == 54 || square == 55 || square == 62)
		{
			if(board.getSquareColor(63) != OthColors.blank) return 0;
		}
		  
		if (square == 48 || square == 49 || square == 57)
		{
			if(board.getSquareColor(56) != OthColors.blank) return 0;
		}
		  
		// if everything else fails, the positional value of the square is returned
		return mBrain[EV[square]];
	}
	
	private int AlphaBeta(OthBoard board, int color, int depth, int a, int b)
	{
		OthBoard temp;
		ArrayList<OthMove> candidates;
		
		// find all the candidate moves for the current player
		candidates = OthManager.getLegalMoves(board, color);
		if(candidates.isEmpty())
		{
			// find all the candidate moves for his opponent
			color = -color;
			candidates = OthManager.getLegalMoves(board, color);
			// and check to see, if the Game is Over!
			if(candidates.isEmpty())
			{
				// the Game is Over...
				return evaluateNode(board);
			}
			
			// the current player simply passes his turn
			// do nothing here ...
		}
		
		// if maximum depth is reached evaluate the position
		if(depth <= 0)
		{
			return evaluateNode(board);
		}
		
		// save a copy of the original board for later use
		// and start alpha-beta search
		temp = new OthBoard(board.getBoard());
		
		// this is the node's score
		int v;
		
		// the AI (computer) is the maximizing player
		if(color == mColor)
		{
			v = MINIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.max(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v > a) a = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// alpha cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
		// the AI's opponent is the minimizing player
		else
		{
			v = MAXIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.min(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v < b) b = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// beta cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
	}
	
	private int EndgameAlphaBeta(OthBoard board, int color, int depth, int a, int b)
	{
		OthBoard temp;
		ArrayList<OthMove> candidates;

		// if maximum depth is reached evaluate the position
		if(depth <= 0)
		{
			return evaluateLeaf(board);
		}
		
		// find all the candidate moves for the current player
		candidates = OthManager.getLegalMoves(board, color);
		if(candidates.isEmpty())
		{
			// find all the candidate moves for his opponent
			color = -color;
			candidates = OthManager.getLegalMoves(board, color);
			// and check to see, if the Game is Over!
			if(candidates.isEmpty())
			{
				// the Game is Over...
				return evaluateLeaf(board);
			}
			
			// the current player simply passes his turn
			// do nothing here ...
		}
		
		// save a copy of the original board for later use
		// and start alpha-beta search
		temp = new OthBoard(board.getBoard());
		
		// this is the node's score
		int v;
		
		// the AI (computer) is the maximizing player
		if(color == mColor)
		{
			v = MINIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.max(v, EndgameAlphaBeta(board, -color, depth-1, a, b));
				if(v > a) a = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// alpha cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
		// the AI's opponent is the minimizing player
		else
		{
			v = MAXIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.min(v, EndgameAlphaBeta(board, -color, depth-1, a, b));
				if(v < b) b = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// beta cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
	}

	@Override
	public OthMove nextMove(OthBoard board)
	{
		ArrayList<OthMove> candidates = OthManager.getLegalMoves(board, mColor);
		if(candidates.isEmpty()) return null;	// no moves available for this position
		
		int emptySquares = board.getDisksOfColor(OthColors.blank);

		int score;
		int a = MINIMUM;
		int b = MAXIMUM;
		OthMove bestMove = null;
		
		// save a copy of the original board for later use
		OthBoard temp = new OthBoard(board.getBoard());
		
		score = MINIMUM; 
		for(OthMove move: candidates)
		{
			// make the move on board
			OthManager.playMove(board, move);

			if(emptySquares <= mEndgamePlay)
				score = Math.max(score, EndgameAlphaBeta(board, -mColor, mEndgamePlay, a, b));
			else
				score = Math.max(score, AlphaBeta(board, -mColor, mSearchDepth, a, b));
			
			if(score > a)
			{
				a = score;
				bestMove = move;
				mScore = score;
			}
			
			// restore the original board
			board.setBoard(temp.getBoard());
		}
		
		return bestMove;
	}

	@Override
	public void setPerfectEndgame(int squares) 
	{
		if(squares > 0) mEndgamePlay = squares;
		else mEndgamePlay = 0;
	}
}

