
public final class OthColors 
{
	public static final int black = +1;
	public static final int white = -1;
	public static final int blank =  0;
}
