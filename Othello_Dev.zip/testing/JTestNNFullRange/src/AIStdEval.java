import java.util.ArrayList;
import java.util.Random;


public class AIStdEval extends OthAIPlayer
{
	private int mSearchDepth;		// maximum search depth of AI (passes are not counted)
	private int mScore;				// the score of the move played by AI
	private boolean[] mStableSquare;
	
	private final int MAXIMUM = Integer.MAX_VALUE;
	private final int MINIMUM = Integer.MIN_VALUE;
	
	// The positional values of the squares in Othello are shown next:
	// a0 -  -  -  -  -  -  -
	// a1 a2 -  -  -  -  -  -	The values of the squares left are
	// a3 a4 a5 -  -  -  -  -	symmetric to the values shown here
	// a6 a7 a8 a9 -  -  -  -	so there is no reason to repeat...
	// -  -  -  -  -  -  -  -
	// -  -  -  -  -  -  -  -	The "brain" of our Othello program
	// -  -  -  -  -  -  -  -	has the form: { a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, mobility, mobQuality }
	// -  -  -  -  -  -  -  -	as the following matrix shows.
	
	private int mBrain[] = { 1000, -60, -160, -16, -46, -2, 14, -36, -10, 6, 72, 4 };
	
	private final double eGreedy = 0.1;		// performs random moves from time to time...
	private final Random rvalue = new Random();
	
	// Evaluation Table. The positional values of a square (s) is brain[EV[s]].
	private static final int EV[]
	= {  0 , 1 , 3 , 6 , 6 , 3 , 1 , 0 ,
		 1 , 2 , 4 , 7 , 7 , 4 , 2 , 1 ,
		 3 , 4 , 5 , 8 , 8 , 5 , 4 , 3 ,
		 6 , 7 , 8 , 9 , 9 , 8 , 7 , 6 ,
		 6 , 7 , 8 , 9 , 9 , 8 , 7 , 6 ,
		 3 , 4 , 5 , 8 , 8 , 5 , 4 , 3 ,
	     1 , 2 , 4 , 7 , 7 , 4 , 2 , 1 ,
		 0 , 1 , 3 , 6 , 6 , 3 , 1 , 0 } ;


	// This Table is used for the Cyclic Swapping of the board
	private static final int Cyclic[]
	= {   0 ,  7 , 63 , 56 ,  8 ,  1 ,  6 ,  15 ,
		 55 , 62 , 57 , 48 , 16 ,  2 ,  5 ,  23 ,
		 47 , 61 , 58 , 40 , 24 ,  3 ,  4 ,  31 ,
		 39 , 60 , 59 , 32 ,  9 , 14 , 54 ,  49 ,
		 17 , 10 , 13 , 22 , 46 , 53 , 50 ,  41 ,
		 25 , 11 , 12 , 30 , 38 , 52 , 51 ,  33 ,
		 18 , 21 , 45 , 42 , 26 , 19 , 20 ,  29 ,
		 37 , 44 , 43 , 34 , 27 , 28 , 36 ,  35 } ;
	
	public AIStdEval()
	{
		mColor = OthColors.black;
		mSearchDepth = 1;
		mStableSquare = new boolean[64];	// initializes stability values to false
	}
	
	public AIStdEval(int color)
	{
		mColor = color;
		mSearchDepth = 1;
		mStableSquare = new boolean[64];	// initializes stability values to false
	}
		
	public AIStdEval(int color, int depth)
	{
		mColor = color;
		setDepth(depth);
		mStableSquare = new boolean[64];	// initializes stability values to false
	}
	
	public AIStdEval(int color, int depth, int[] brain)
	{
		mColor = color;
		setDepth(depth);
		mStableSquare = new boolean[64];	// initializes stability values to false
		
		setBrain(brain);
	}

	@Override
	public String getScore()
	{
		return String.valueOf(mScore);
	}
	
	@Override
	public void setDepth(int depth)
	{
		if(depth < 1) mSearchDepth = 1;
		else mSearchDepth = depth;
	}
	
	@Override
	public void setBrain(int[] brain)
	{
		// check for the correct number of parameters
		if(brain != null && brain.length == mBrain.length)
		{
			// set the new brain parameters here ...
			for(int i = 0; i < mBrain.length; ++i)
			{
				mBrain[i] = brain[i];
			}
				
			return;
		}

		String who = (mColor == OthColors.black) ? "(black)":"(white)";
				
		System.err.println("ERROR" + who + ": AI's brain must have exactly " + mBrain.length + " parameters.");
		System.err.println("Default values are used...");
	}
	
	// this is called when the Game is Over
	// position is evaluated from AI's(computer) perspective ...
	private int evaluateLeaf(OthBoard board)
	{
		int score = mBrain[0]*(board.getDisksOfColor(OthColors.black) - board.getDisksOfColor(OthColors.white));
		
		if(mColor == OthColors.white) return -score;
		return score;
	}
	
	// this is called when depth is exhausted
	// position is evaluated from AI's(computer) perspective ...
	private int evaluateNode(OthBoard board)	
	{
		// for positional calculation...
		int positional = 0;
		
		// for mobility calculation...
		int blackMoves = 0;			// number of black's legal moves
		int whiteMoves = 0;			// number of white's legal moves
		int blacksBest = MINIMUM;	// The score of black's best positional legal move
		int whitesBest = MINIMUM;	// The score of white's best positional legal move
		
		int sq;
		for (int square = 0; square < 64; ++square)
		{
			sq = Cyclic[square];
			
			if(board.getColorOfSquare(sq) == OthColors.black)
			{
				positional += squareValue(board, sq, OthColors.black);
			}
			else
			if(board.getColorOfSquare(sq) == OthColors.white)
			{
				positional -= squareValue(board, sq, OthColors.white);
			}
			else
			{
				if(OthManager.isLegalMove(board, sq, OthColors.black))
				{
					++blackMoves;
					if(mBrain[EV[sq]] > blacksBest) blacksBest = mBrain[EV[sq]];
				}	
				
				if(OthManager.isLegalMove(board, sq, OthColors.white))
				{
					++whiteMoves;
					if(mBrain[EV[sq]] > whitesBest) whitesBest = mBrain[EV[sq]];
				}	
			}
		}
		
		if(blacksBest == MINIMUM) blacksBest = 0;
		if(whitesBest == MINIMUM) whitesBest = 0;

		int mobility = mBrain[10]*(blackMoves - whiteMoves)/(blackMoves + whiteMoves);
		int mQuality = mBrain[11]*(blacksBest - whitesBest);
		
		// Effective mobility. That means mobility with some extra "bonuses"
		int efMobility = mobility + mQuality;
		
		// restore stability values
		for(int square = 0; square < 64; ++square)
		{
			mStableSquare[square] = false;
		}
		
		// return the evaluation...
		if(mColor == OthColors.white) return -positional - efMobility;
		return positional + efMobility;
	}
	
	private int squareValue(OthBoard board, int square, int color)
	{
		int Sa , Sb;		// traverse squares in opposite directions
		boolean Xa , Xb;	// partial stabilities for the square (square) for two opposite directions.
		
		int stabilityValue = 0;
	
		
		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.L[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.R[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getColorOfSquare(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.L[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getColorOfSquare(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.R[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------
		  
		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.UL[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.DR[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getColorOfSquare(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.UL[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getColorOfSquare(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.DR[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------

		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.U[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.D[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getColorOfSquare(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.U[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getColorOfSquare(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.D[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// ------------------------------------------------------------

		Sa = Sb = square;
		Xa = false;
        Xb = false;
        
        // first, check for linear stability of the square (square) of color (color)
        do
        {
        	if(mStableSquare[Sa]) 
        	{
        		Xa = true; 
        		break;				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sa = OthManager.UR[Sa];	// get the next square to one direction ...
        	
        	if(Sa < 0)
        	{
        		Xa = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sa) == color);
		  
        do
        {
        	if(mStableSquare[Sb]) 
        	{
        		Xb = true; 
        		break; 				// if we hit a stable disk of our color, there is linear stability
        	}
        	
        	Sb = OthManager.DL[Sb];	// get the next square to the opposite direction ...
        	
        	if(Sb < 0)
        	{
        		Xb = true; 
        		break;				// if we hit a boundary wall, there is linear stability 
        	}
        }
        while(board.getColorOfSquare(Sb) == color);
          
		if(Xa || Xb) ++stabilityValue;
		else
		// next, we check for partial stabilities
		{
			while(board.getColorOfSquare(Sa) != OthColors.blank)
	        {
	        	if(mStableSquare[Sa]) 
	        	{
	        		Xa = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sa = OthManager.UR[Sa];	// get the next square to one direction ...
	        	
	        	if(Sa < 0)
	        	{
	        		Xa = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
	        
			while(board.getColorOfSquare(Sb) != OthColors.blank)
	        {
	        	if(mStableSquare[Sb]) 
	        	{
	        		Xb = true; 
	        		break;				// if we hit a stable disk of the opposite color, there is partial stability
	        	}
	        	
	        	Sb = OthManager.DL[Sb];	// get the next square to one direction ...
	        	
	        	if(Sb < 0)
	        	{
	        		Xb = true; 
	        		break;				// if we hit a boundary wall, there is partial stability 
	        	}
	        }
			
			if(Xa && Xb) ++stabilityValue;
		}
		
		// if the disk in (square) is absolutely stable, it achieves the maximum value
		if(stabilityValue == 4) 
		{
			mStableSquare[square] = true; 
			return mBrain[0]; 
		}

		// when a corner is occupied, its adjacent squares are unimportant for both players
		if (square ==  1 || square ==  8 || square ==  9)
		{
			if(board.getColorOfSquare(0) != OthColors.blank) return 0;
		}
		  
		if (square ==  6 || square == 14 || square == 15)
		{
			if(board.getColorOfSquare(7) != OthColors.blank) return 0;
		}
		  
		if (square == 54 || square == 55 || square == 62)
		{
			if(board.getColorOfSquare(63) != OthColors.blank) return 0;
		}
		  
		if (square == 48 || square == 49 || square == 57)
		{
			if(board.getColorOfSquare(56) != OthColors.blank) return 0;
		}
		  
		// if everything else fails, the positional value of the square is returned
		return mBrain[EV[square]];
	}
	
	private int AlphaBeta(OthBoard board, int color, int depth, int a, int b)
	{
		OthBoard temp;
		ArrayList<OthMove> candidates;

		// find all the candidate moves for the current player
		candidates = OthManager.getLegalMoves(board, color);
		if(candidates.isEmpty())
		{
			// find all the candidate moves for his opponent
			color = -color;
			candidates = OthManager.getLegalMoves(board, color);
			// and check to see, if the Game is Over!
			if(candidates.isEmpty())
			{
				// the Game is Over...
				return evaluateLeaf(board);
			}
			
			// the current player simply passes his turn
			// do nothing here ...
		}
		else
		{
			if(depth <= 0)
			{
				return evaluateNode(board);
			}
		}
		
		// save a copy of the original board for later use
		// and start alpha-beta search
		temp = new OthBoard(board.getBoard());
		
		// this is the node's score
		int v;
		
		// the AI (computer) is the maximizing player
		if(color == mColor)
		{
			v = MINIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.max(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v > a) a = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// alpha cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
		// the AI's opponent is the minimizing player
		else
		{
			v = MAXIMUM;
			for(OthMove move: candidates)
			{
				// make the move on board
				OthManager.playMove(board, move);
				
				v = Math.min(v, AlphaBeta(board, -color, depth-1, a, b));
				if(v < b) b = v;
				
				// restore the original board
				board.setBoard(temp.getBoard());
		        
				// beta cut-off
		        if(b <= a) break;
			}
			
			return v;
		}
	}

	@Override
	public OthMove nextMove(OthBoard board)
	{
		ArrayList<OthMove> candidates = OthManager.getLegalMoves(board, mColor);
		if(candidates.isEmpty()) return null;	// no moves available for this position
		
		// opening book ?
		if(board.getDisksOfColor(OthColors.blank) > 58) return candidates.get(rvalue.nextInt(candidates.size()));
		
		int score;
		int a = MINIMUM;
		int b = MAXIMUM;
		OthMove bestMove = null;
		
		// exhaustive search for the last few squares
		//if(board.getDisksOfColor(OthColors.blank) < 15) mSearchDepth = 30;	// this one is never reached :)
		
		// save a copy of the original board for later use
		OthBoard temp = new OthBoard(board.getBoard());
		
		score = MINIMUM; 
		for(OthMove move: candidates)
		{
			// make the move on board
			OthManager.playMove(board, move);

			score = Math.max(score, AlphaBeta(board, -mColor, mSearchDepth-1, a, b));
			
			if(score > a)
			{
				a = score;
				bestMove = move;
				mScore = score;
			}
			
			// restore the original board
			board.setBoard(temp.getBoard());
		}
		
		if(rvalue.nextDouble() < eGreedy) return candidates.get(rvalue.nextInt(candidates.size()));
		return bestMove;
	}
}

