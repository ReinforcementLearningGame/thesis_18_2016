package com.vasmakk.othello;

import java.io.InputStream;

public abstract class AndOthAIPlayer extends AndOthPlayer
{
	protected boolean stopThinking;
	
	public abstract boolean setDepth(int depth);		// sets AI's search depth
	public abstract boolean setBrain(int[] brain);		// sets AI's weights manually (integer values)
	public abstract boolean setBrain(double[] brain);	// sets AI's weights manually (double precision values)
	public abstract boolean loadBrain(InputStream in);	// loads AI's weights from a source
	public abstract void setPerfectEndgame(int depth);	// sets depth, for a perfect end-game play ...
	
	// abruptly terminates AI's thinking
	public void stopThinking()
	{
		stopThinking = true;
	}
}
