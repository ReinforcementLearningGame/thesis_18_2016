package com.vasmakk.othello;

import java.io.IOException;
import java.util.ArrayList;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;


public class GameScreen extends View
{
	final int BLACK = AndOthColors.black;
	final int WHITE = AndOthColors.white;
	
	// id's for sound effects
	int SFX_AI_MOVES;
	int SFX_OP_MOVES;
	int VOC_ILLEGAL_MOVE;
	int VOC_I_WIN;
	int VOC_U_WIN;
	int VOC_ITS_A_DRAW;
	int VOC_U_MUST_PASS;
	int VOC_LET_THE_GAME_BEGIN;
	
	int unit;		// the smallest length to be used as a unit of measurement of the screen
	int pX;			// X point selected on the mobile screen
	int pY;			// Y point selected on the mobile screen
	
	int aiColor;	// current AI's color
	int opColor;	// current AI Opponent's color
	
	int iniAiColor;	// initial AI's color
	int iniOpColor;	// initial AI Opponent's color
	
	boolean aiIsThinking;
	boolean playerPasses;
	String MOVE_SEQUENCE;
	
	ArrayList<Bitmap> digits;		// digits 0, 1, 2, ... 9 as images
	ArrayList<AndOthBoard> pList;	// for undo/re-do operations ...
	int pIndex;						// for undo/re-do operations ...
	
	Paint background;				// the background...
	SoundPool sounds;				// the sounds of the game
	
	Bitmap blackDisk, whiteDisk, emptySquare;
	
	Bitmap btnNewGame, btnNewGameClicked;
	Bitmap btnUndo, btnUndoClicked;
	Bitmap btnRedo, btnRedoClicked;
	Bitmap btnPass, btnPassClicked;
	

	Bitmap imgIWin, imgUWin, imgDraw, imgBlackTurn, imgWhiteTurn;
	Bitmap txtWait, txtPass, txtPlay, txtBlackTurn, txtWhiteTurn, txtGameOver;
	
	Bitmap undo, redo, game, infoImage, infoLabel;
	
	// digits ...
	Bitmap d0, d1, d2, d3, d4, d5, d6, d7, d8, d9, dig;
	
	AndOthBook book;
	AndOthBoard board;
	AndOthAIPlayer ai;

	Context context;
	Handler hnd = new Handler();
	
	Runnable updateGUI = new Runnable() 
	{
		@Override
		public void run() 
		{
			invalidate();
		}
	};
	
	
	Runnable itIsAIsTurn = new Runnable()
	{
		@Override
		public void run() 
		{
			// proceed to the game
			aiIsThinking = true;
			
			AndOthMove mv;
			AndOthBoard tb;
			String square;
			
			// read from the opening book if it was told to do so ...
			if(GameOptions.openingBook)
			{
				square = book.reply(MOVE_SEQUENCE);
			}
			else
			{
				square = "";
			}
			
			if(square.isEmpty())
			{
				tb = new AndOthBoard();
				
				// create a copy of the original position to prevent screen-flickering
				tb.setBoard(board.getBoard());
				
				// search for best move on that copy
				mv = ai.nextMove(tb);

				// finally restore the original position
				board.setBoard(tb.getBoard());
			}
			else
			{
				// best move comes from the book
				mv = new AndOthMove(AndOthManager.getSquareValue(square), aiColor);
			}


			if(mv != null)
			{
				// play a sound (if option selected)
				playSound(SFX_AI_MOVES);
				
				// AI plays its move
				AndOthManager.playMove(board, mv);
				
				if(square.isEmpty())
				{
					square = AndOthManager.getSquareLabel(mv.getSquare());
				}
				
				// A new position will be added to the list
				// this is the position, after the AI has made its move
				tb = new AndOthBoard(board.getBoard());
				
				// also the move is added to the move sequence ...
				MOVE_SEQUENCE += square;
			
				// check if the game is over before proceeding
				if(theGameIsOver())
				{
					// initialize the appropriate game-over messages and play a suitable sound (if option selected)
					setGameOverState();
				
					// the game is over... It's nobody's turn!
					tb.setTurn(0);
				}
				else
				if(!movesExist(opColor))
				{
					// play a sound (if option selected)
					playSound(VOC_U_MUST_PASS);
					
					playerPasses = true;
				
					infoImage = btnPass;
					infoLabel = txtPass;
				
					// AI's opponent passes
					tb.setTurn(aiColor);
				}
				else
				{
					if(aiColor == WHITE)
					{
						infoImage = imgBlackTurn;
					}
					else 
					{
						infoImage = imgWhiteTurn;
					}
				
					infoLabel = txtPlay;
					tb.setTurn(opColor);
				}
			
				// add the new position to the list
				pList.add(tb);
				++pIndex;
			}
			
			// update the User Interface
			hnd.post(updateGUI);
			
			aiIsThinking = false;
		}
	};
	
	
	public GameScreen(Context context) 
	{
		super(context);
		this.context = context;

		background = new Paint();
		background.setColor(Color.rgb(0x14, 0x28, 0x3C));

		digits = new ArrayList<Bitmap>();
		
		initializeSounds();

		setGame(GameOptions.personalityType, GameOptions.personalityFile, GameOptions.aiColor, 
				Integer.parseInt(GameOptions.midgameSearchDepth[GameOptions.midgameSearchIndex]),
				Integer.parseInt(GameOptions.endgameSearchDepth[GameOptions.endgameSearchIndex]));
	}
	
	
	@Override
	protected void onDraw(Canvas canvas) 
	{
		canvas.drawPaint(background);
		
		int x, y, sqr;
		
		for(int i = 0; i < 64; ++i)
		{
			x = i%8;
			y = i/8;
			
			sqr = board.getSquareColor(i);
			
			draw(canvas, emptySquare, 2*x, 2*y);
			
			if(sqr == BLACK)
			{
				draw(canvas, blackDisk, 2*x, 2*y);
			}
			else
			if(sqr == WHITE)
			{
				draw(canvas, whiteDisk, 2*x, 2*y);
			}
		}
		
		draw(canvas, infoLabel, 5, 16);

		draw(canvas, undo, 0, 19);
		draw(canvas, redo, 10, 19);	
		draw(canvas, infoImage, 6, 18);
		draw(canvas, game, 5, 23);
		
		int blackDisks = board.getDisksOfColor(BLACK);
		int whiteDisks = board.getDisksOfColor(WHITE);
		
		draw(canvas, blackDisk, 0, 23);
		x = blackDisks/10;
		y = blackDisks%10;
		if(x > 0)
		{
			dig = digits.get(x);
			draw(canvas, dig, 2, 23);
		}
		
		dig = digits.get(y);
		draw(canvas, dig, 3, 23);
		
		draw(canvas, whiteDisk, 12, 23);
		x = whiteDisks/10;
		y = whiteDisks%10;
		if(x > 0)
		{
			dig = digits.get(x);
			draw(canvas, dig, 14, 23);
		}
		
		dig = digits.get(y);
		draw(canvas, dig, 15, 23);
		
	}

	
	@Override
	protected void onSizeChanged(int xNew, int yNew, int xOld, int yOld)
	{
	     super.onSizeChanged(xNew, yNew, xOld, yOld);

	     // first set the scale unit. This is the smallest dimension of the mobile-screen
	     unit = xNew/16;
	     
	     blackDisk = scaleImage(2, 2, R.drawable.disk_black);
	     emptySquare = scaleImage(2, 2, R.drawable.square_empty);
	     whiteDisk = scaleImage(2, 2, R.drawable.disk_white);
	     
	     btnUndo = scaleImage(6, 2, R.drawable.button_undo_off);
	     btnUndoClicked = scaleImage(6, 2, R.drawable.button_undo_on);
	     
	     btnRedo = scaleImage(6, 2, R.drawable.button_redo_off);
	     btnRedoClicked = scaleImage(6, 2, R.drawable.button_redo_on);
	     
	     btnPass = scaleImage(4, 4, R.drawable.button_pass_off);
	     btnPassClicked = scaleImage(4, 4, R.drawable.button_pass_on);
	     
	     btnNewGame = scaleImage(6, 2, R.drawable.button_new_game_off);
	     btnNewGameClicked = scaleImage(6, 2, R.drawable.button_new_game_on);
	     
	     imgBlackTurn = scaleImage(4, 4, R.drawable.image_blacks_turn);
	     imgWhiteTurn = scaleImage(4, 4, R.drawable.image_whites_turn);
	     
	     imgIWin = scaleImage(4, 4, R.drawable.image_iwin);
	     imgUWin = scaleImage(4, 4, R.drawable.image_uwin);
	     imgDraw = scaleImage(4, 4, R.drawable.image_draw);
	     
	     txtWait = scaleImage(6, 2, R.drawable.label_ai_is_thinking);
	     txtPass = scaleImage(6, 2, R.drawable.label_you_must_pass);
	     txtPlay = scaleImage(6, 2, R.drawable.label_it_is_your_turn);
	     
	     txtGameOver = scaleImage(6, 2, R.drawable.label_game_over);
	     txtBlackTurn = scaleImage(6, 2, R.drawable.label_black_to_play);
	     txtWhiteTurn = scaleImage(6, 2, R.drawable.label_white_to_play);
	     
	     d0 = scaleImage(1, 2, R.drawable.d0); digits.add(d0);
	     d1 = scaleImage(1, 2, R.drawable.d1); digits.add(d1);
	     d2 = scaleImage(1, 2, R.drawable.d2); digits.add(d2);
	     d3 = scaleImage(1, 2, R.drawable.d3); digits.add(d3);
	     d4 = scaleImage(1, 2, R.drawable.d4); digits.add(d4);
	     d5 = scaleImage(1, 2, R.drawable.d5); digits.add(d5);
	     d6 = scaleImage(1, 2, R.drawable.d6); digits.add(d6);
	     d7 = scaleImage(1, 2, R.drawable.d7); digits.add(d7);
	     d8 = scaleImage(1, 2, R.drawable.d8); digits.add(d8);
	     d9 = scaleImage(1, 2, R.drawable.d9); digits.add(d9);
	     
	     // initializing ...
	     undo = btnUndo;
	     redo = btnRedo;
	     game = btnNewGame;
	     
	     
	     infoImage = imgBlackTurn;
	     
	     if(GameOptions.aiColor == WHITE)
	     {
	    	 infoLabel = txtPlay;
	     }
	     else
	     {
	    	 infoLabel = txtWait;
	    	 
	    	 // AI starts the game
	    	 Thread t = new Thread(itIsAIsTurn);
			 t.start();
	     }
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) 
	{
		// call the superclass
		performClick();
		
		// no touch events are handled while AI is thinking
		if(aiIsThinking) return true;
		
		int action = event.getAction();
		
		pX = (int)event.getX();
		pY = (int)event.getY();
		
		switch(action)
		{
			case MotionEvent.ACTION_DOWN:

				// handle the undo button
				if(!playerPasses && areaTouched(0, 19, 6, 21))
				{
					undo = btnUndoClicked;
					invalidate();
				}
				
				// handle the re-do button
				if(!playerPasses && areaTouched(10, 19, 16, 21))
				{
					redo = btnRedoClicked;
					invalidate();
				}
				
				// handle the pass button
				if( playerPasses && areaTouched(6, 18, 10, 22))
				{
					infoImage = btnPassClicked;
					invalidate();
				}
				
				// handle the new-game button
				if(areaTouched(5, 23, 11, 25))
				{
					game = btnNewGameClicked;
					invalidate();
				}
				
				break;
				
			case MotionEvent.ACTION_UP:
				
				// handle the undo button
				if(!playerPasses && areaTouched(0, 19, 6, 21))
				{
					undo = btnUndo;
					
					if(--pIndex < 0) 
					{
						pIndex = 0;
					}
					else
					{
						board = pList.get(pIndex);
					
						opColor = board.getTurn();
						aiColor = -opColor;
						ai.setColor(aiColor);
						
						if(opColor == BLACK)
						{
							infoLabel = txtBlackTurn;
							infoImage = imgBlackTurn;
						}
						else
						{
							infoLabel = txtWhiteTurn;
							infoImage = imgWhiteTurn;
						}
					}
					
					invalidate();
				}
				
				// handle the re-do button
				if(!playerPasses && areaTouched(10, 19, 16, 21))
				{
					redo = btnRedo;
					
					if(++pIndex >= pList.size())
					{
						pIndex = pList.size()-1;
					}
					else
					{
						board = pList.get(pIndex);

						opColor = board.getTurn();
						aiColor = -opColor;
						ai.setColor(aiColor);
						
						if(opColor == BLACK)
						{
							infoLabel = txtBlackTurn;
							infoImage = imgBlackTurn;
						}
						else
						if(opColor == WHITE)
						{
							infoLabel = txtWhiteTurn;
							infoImage = imgWhiteTurn;
						}
						else
						{
							infoLabel = txtGameOver;
						}
					}
					
					invalidate();
				}
				
				// handle the pass button
				if( playerPasses && areaTouched(6, 18, 10, 22))
				{
					playerPasses = false;
					
					if(aiColor == BLACK)
					{
						infoImage = imgBlackTurn;
					}
					else 
					{
						infoImage = imgWhiteTurn;
					}
					
					infoLabel = txtWait;
					invalidate();
					
					// start AI's thinking after pass...
					Thread t = new Thread(itIsAIsTurn);
					t.start();
				}
				
				// handle the new-game state
				if(areaTouched(5, 23, 11, 25))
				{
					playerPasses = false;
					
				    infoImage = imgBlackTurn;
				    game = btnNewGame;
				    
					// initialize the board the lists e.t.c
					board.reset();
					pList.clear();
					
					// create an initial board and add it to the board list
					AndOthBoard tb = new AndOthBoard();
					pList.add(tb);
					pIndex = 0;
					
					MOVE_SEQUENCE = "";
									    
				    // initialize colors
				    aiColor = iniAiColor;
				    opColor = iniOpColor;
				    ai.setColor(aiColor);
				    
				    // announce the start of the game (if option selected)
			    	playSound(VOC_LET_THE_GAME_BEGIN);
			    	
				    if(aiColor == WHITE)
				    {
				    	infoLabel = txtPlay;
				    	invalidate();
				    }
				    else
				    {
				    	infoLabel = txtWait;
				    	invalidate();
						
				    	// AI starts the game
				    	Thread t = new Thread(itIsAIsTurn);
				    	t.start();
				    }
				    
				}
				
				// handle the clicks on the board
				if(!playerPasses && areaTouched(0, 0, 16, 16))
				{
					// if the game is over skip the rest ...
					if(theGameIsOver())
					{
						break;
					}
					
					// or else, proceed to the game ...
					int square = 8*(pY/(2*unit)) + pX/(2*unit);
					
					// sometimes, when the finger touches the margin between the Othello board and the Screen
					// the preceding expression produces values out of the range [0, 63]. These values
					// are not squares, and therefore must be excluded.
					if(square < 0 || square > 63)
					{
						break;
					}
					
					if(AndOthManager.isALegalMove(board, square, opColor))
					{
						// play a sound (if option selected)
						playSound(SFX_OP_MOVES);
						
						AndOthMove mv = new AndOthMove(square, opColor);

						// initially, clear the list from this point to the end ...
						while(pIndex < pList.size()) 
						{
							pList.remove(pIndex);
						}
						
						// the current position becomes the terminal node
						AndOthBoard tb = new AndOthBoard(board.getBoard());
						tb.setTurn(opColor);
						pList.add(tb);

						// AI's opponent plays his move
						AndOthManager.playMove(board, mv);
						
						// A new position will be added to the list
						// this is the position, after the AI's opponent has made his move
						tb = new AndOthBoard(board.getBoard());
							
						// also the move is added to the move sequence ...
						MOVE_SEQUENCE += AndOthManager.getSquareLabel(square);
						
						// again check if the game is over before proceeding
						if(theGameIsOver())
						{
							// initialize the appropriate game-over messages and play a suitable sound (if option selected)
							setGameOverState();
							
							// the game is over... It's nobody's turn!
							tb.setTurn(0);
						}
						else
						if(!movesExist(aiColor))
						{
							// AI passes ...
							tb.setTurn(opColor);
						}
						else
						{
							if(aiColor == BLACK)
							{
								infoImage = imgBlackTurn;
							}
							else 
							{
								infoImage = imgWhiteTurn;
							}
						
							infoLabel = txtWait;
							tb.setTurn(aiColor);
						}
						
						// add the new position to the list
						pList.add(tb);
						++pIndex;
						
						invalidate();

						// start AI's thinking...
						Thread t = new Thread(itIsAIsTurn);
						t.start();
					}
					else
					{
						// play a sound (if option selected)
						playSound(VOC_ILLEGAL_MOVE);
					}
				}
				
				break;
		}
		
		return true;
	}

	
	@Override
	public boolean performClick() 
	{
		super.performClick();
		return true;
	}

	///////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	private boolean areaTouched(int x1, int y1, int x2, int y2)
	{
		if(pX > x2*unit || pX < x1*unit) return false;
		if(pY > y2*unit || pY < y1*unit) return false;
		return true;
	}
	
	private boolean movesExist(int color)
	{
		for(int square = 0; square < 64; ++square)
		{
			if(AndOthManager.isALegalMove(board, square, color)) return true;
		}
		
		return false;
	}
	
	private boolean theGameIsOver()
	{
		for(int square = 0; square < 64; ++square)
		{
			if(AndOthManager.isALegalMove(board, square, WHITE)) return false;
			if(AndOthManager.isALegalMove(board, square, BLACK)) return false;
		}
		
		return true;
	}
	
	private Bitmap scaleImage(int X, int Y, int resource)
	{
		Bitmap tmp = BitmapFactory.decodeResource(getResources(), resource);
		return Bitmap.createScaledBitmap(tmp, X*unit, Y*unit, false);
	}
	
	private void draw(Canvas canvas, Bitmap b, int X, int Y)
	{
		canvas.drawBitmap(b, X*unit, Y*unit, null);
	}
	
	
	private void setGame(String aiType, String aiFile, int aiColor, int aiMidDepth, int aiEndDepth)
	{
		if(aiType.equalsIgnoreCase("64-16x8-8-1"))
		{
			ai = new N64_16x8_8_1();
		}
		else
		if(aiType.equalsIgnoreCase("64-16x8-8-4-1"))
		{
			ai = new N64_16x8_8_4_1();
		}
		else
		{
			ai = new Standard_Eval();
		}
		
		this.aiColor = aiColor;
		this.opColor =-aiColor;
		
		iniAiColor = aiColor;
		iniOpColor =-aiColor;
		
		AssetManager am = context.getResources().getAssets();
		
		try 
		{
			ai.loadBrain(am.open(aiFile));
		}
		catch (IOException e)
		{
			// something went terribly wrong here...
		}
		
		ai.setColor(aiColor);
		ai.setDepth(aiMidDepth);
		ai.setPerfectEndgame(aiEndDepth);
		
		try 
		{
			book = new AndOthBook(am.open("openings"));
		} 
		catch (IOException e) 
		{
			// something went terribly wrong here...
		}
		
		board = new AndOthBoard();		
		pList = new ArrayList<AndOthBoard>();
		
		// create a temporary initial board and add it to the board list
		AndOthBoard tb = new AndOthBoard();
		pList.add(tb);
		pIndex = 0;

		MOVE_SEQUENCE = "";
	}
	
	@SuppressWarnings("deprecation")
	private void initializeSounds()
	{
		if(!GameOptions.soundEffects)
		{
			return;
		}

		sounds = new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
		
		SFX_AI_MOVES = sounds.load(context, R.raw.sfx_ai_moves, 1);
		SFX_OP_MOVES = sounds.load(context, R.raw.sfx_op_moves, 1);
		VOC_ILLEGAL_MOVE = sounds.load(context, R.raw.voc_illegal_move, 1);
		
		VOC_I_WIN = sounds.load(context, R.raw.voc_i_win, 1);
		VOC_U_WIN = sounds.load(context, R.raw.voc_u_win, 1);
		VOC_ITS_A_DRAW = sounds.load(context, R.raw.voc_its_a_draw, 1);
		VOC_U_MUST_PASS = sounds.load(context, R.raw.voc_u_must_pass, 1);
		VOC_LET_THE_GAME_BEGIN = sounds.load(context, R.raw.voc_let_the_game_begin, 1);
	}
	
	private void playSound(int id)
	{
		if(!GameOptions.soundEffects)
		{
			return;
		}
		
		if(sounds != null)
		{
			sounds.play(id, 1.0f, 1.0f, 1, 0, 1.0f);
		}
	}
	
	private void setGameOverState()
	{
		int aiDisks = board.getDisksOfColor(aiColor);
		int opDisks = board.getDisksOfColor(opColor);
		
		if(aiDisks > opDisks)
		{
			infoImage = imgIWin;
		}
		else
		if(aiDisks < opDisks)
		{
			infoImage = imgUWin;
		}
		else
		{
			infoImage = imgDraw;
		}
		
		infoLabel = txtGameOver;
		
		// nothing more to do if the sound option is not enabled...
		if(!GameOptions.soundEffects)
		{
			return;
		}

		if(aiDisks > opDisks)
		{
			playSound(VOC_I_WIN);
		}
		else
		if(aiDisks < opDisks)
		{
			playSound(VOC_U_WIN);
		}
		else
		{
			playSound(VOC_ITS_A_DRAW);
		}
	}
	
	public void destroy()
	{
		// interrupt AI's thoughts
		ai.stopThinking();
		
		// any resources reserved by media-player are released
		if(sounds != null)
		{
			sounds.release();
			sounds = null;
		}
		
		// any resources reserved by lists, are also released
		pList.clear();
		pList = null;
		
		digits.clear();
		digits = null;
	}

}
