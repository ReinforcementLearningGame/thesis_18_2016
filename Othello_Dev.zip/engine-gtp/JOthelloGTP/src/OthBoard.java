
public class OthBoard
{	
	private int[] mSquares;			// an 64 element array contains each square's colors
	
	// the constructors ...
	public OthBoard()
	{
		mSquares = new int[64];

		mSquares[27] = OthColors.white; 
		mSquares[36] = OthColors.white;
		mSquares[28] = OthColors.black;
		mSquares[35] = OthColors.black;
	}
	
	public OthBoard(int[] squares)
	{
		mSquares = new int[64];
		setBoard(squares);
	}
	
	// setters ...
	public void setBoard(int[] squares)
	{
		for(int i = 0; i < 64; ++i)
		{
			mSquares[i] = squares[i];
		}
	}
	
	public void setSquareColor(int square, int color)
	{
		mSquares[square] = color;
	}
	

	
	// getters ...	
	public int[] getBoard()
	{
		int[] squares = new int[64];
		
		for(int i = 0; i < 64; ++i)
		{
			squares[i] = mSquares[i];
		}
		
		return squares;
	}
	
	public int getSquareColor(int square)
	{
		return mSquares[square];
	}
	
	public int getDisksOfColor(int color)
	{
		int disks = 0;
		for(int i = 0; i < 64; ++i)
		{
			if(mSquares[i] == color) ++disks;
		}
		
		return disks;
	}
	
	// other methods
	public void clear()
	{
		for(int i = 0; i < 64; ++i)
		{
			mSquares[i] = OthColors.blank;
		}
	}
	
	public void reset()
	{
		clear();
		
		mSquares[27] = OthColors.white; 
		mSquares[36] = OthColors.white;
		mSquares[28] = OthColors.black;
		mSquares[35] = OthColors.black;
	}
	
	public void reverse()
	{
		for(int i = 0; i < 64; ++i) mSquares[i] = -mSquares[i];
	}
	
	public void view()
	{
		int index = 0;
		
		for(int i = 0; i < 8; ++i) System.out.print(" " + (char)('A' + i) + " ");
		System.out.println();
		
		for(int i = 0; i < 8; ++i)
		{
			for(int j = 0; j < 8; ++j)
			{
				if(mSquares[index] == OthColors.blank) System.out.print(" - ");
				if(mSquares[index] == OthColors.black) System.out.print(" X ");
				if(mSquares[index] == OthColors.white) System.out.print(" O ");
				++index;
			}
			System.out.println(i + 1);
		}
	}
}
