
public abstract class OthPlayer 
{
	protected int mColor;
	
	// the way different kind of players select and make their move, strongly differs.
	// so this method should be declared abstract ...
	public abstract OthMove nextMove(OthBoard board);
	
	
	public void setColor(int color)
	{
		mColor = color;
	}
	
	public int getColor()
	{
		return mColor;
	}
}
