import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;


public class JCoEvESmpl
{
	private static double[][] brains;	// each "brain" actually contains the weights to be optimized
	private static double[][] sigmas;	// the self-adaptation (strategy) parameters
	private static int[] fitness;		// the fitness of each brain
	
	private static int PARENTS;			// the parent population
	private static int CHILDREN;		// the children population
	private static double sigma;		// initial sigma value
	private static int GENERATIONS;		// the number of generations the evolutionary algorithm should applied
	private static int GEN_GAMES;		// games played per generation
	private static int nWeights;		// the number of weights of the Neural Net
	
	static int netSave;
	static int netType;
	static int nnDepth;
	
	// for multi-threaded tasks...
	private static int nThreads;		// number of threads
	private static Thread[] tds;		// an array of threads
	
	private static final Random rvalue = new Random();
	
	
	static class Competition implements Runnable
	{
		@Override
		public void run()
		{
			int ds1, ds2;	// number of disks for each player, after one game
			int thrGames;	// number of games per thread
			int thrIndex;	// index of current thread
			int min, max;	// lower and upper index limits
			
			OthAIPlayer  p1 , p2;	// the competing players
			OthBoard board = new OthBoard();
			
			thrGames = (PARENTS + CHILDREN) / nThreads;
			thrIndex = Integer.parseInt(Thread.currentThread().getName());
			
			min = thrIndex*thrGames;
			if(thrIndex == nThreads-1) max = PARENTS + CHILDREN; else max = min + thrGames;
			
			p1 = null;
			p2 = null;
			
			if(netType == 0) 
			{
				p1 = new NN_64_16x8_8_1(); 
				p2 = new NN_64_16x8_8_1(); 
			}
			else
			if(netType == 1) 
			{
				p1 = new NN_64_16x8_8_4_1(); 
				p2 = new NN_64_16x8_8_4_1();; 
			}
			else
			if(netType == 2) 
			{
				p1 = new NN_64_91_40_10_1(); 
				p2 = new NN_64_91_40_10_1(); 
			}
			else
			if(netType == 3) 
			{
				p1 = new NN_64_40_10_1(); 
				p2 = new NN_64_40_10_1(); 
			}
			
			// set the players's search depth
			p1.setDepth(nnDepth);
			p2.setDepth(nnDepth);
			
			// start the tournament...
			for(int i = min; i < max; ++i)
			{	
				// set the player's brain
				p1.setBrain(brains[i]);
				
				for(int j = i + 1; j < PARENTS + CHILDREN; ++j)
				{
					// set the player's brain
					p2.setBrain(brains[j]);
					
					// set up the board and the players's color
					board.reset();
						
					p1.setColor(OthColors.black);
					p2.setColor(OthColors.white);
						
					// this is the first game where p1 plays black and p2 plays white
					OthManager.playQuietly(board, p1, p2);
					
					ds1 = board.getDisksOfColor(OthColors.black);
					ds2 = board.getDisksOfColor(OthColors.white);
					
					synchronized(this)
					{
						++GEN_GAMES;
						
						// we take into account the official rules for scoring
						// (empty squares are attributed to the winner)
						if(ds1 > ds2)
						{
							fitness[i] += 2000 + ds1 - ds2;
						}
						else
						if(ds1 < ds2)
						{
							fitness[j] += 2000 + ds2 - ds1;
						}
						else
						{
							fitness[i] += 1000;
							fitness[j] += 1000;
						}
					}

					// setting up the board and the players's color
					board.reset();
						
					p2.setColor(OthColors.black);
					p1.setColor(OthColors.white);
						
					// this is the second game where p2 plays black and p1 plays white
					OthManager.playQuietly(board, p2, p1);

					ds2 = board.getDisksOfColor(OthColors.black);
					ds1 = board.getDisksOfColor(OthColors.white);
					
					synchronized(this)
					{
						++GEN_GAMES;
						
						// we take into account the official rules for scoring
						// (empty squares are attributed to the winner)
						if(ds2 > ds1)
						{
							fitness[j] += 2000 + ds2 - ds1;
						}
						else
						if(ds2 < ds1)
						{
							fitness[i] += 2000 + ds1 - ds2;
						}
						else
						{
							fitness[i] += 1000;
							fitness[j] += 1000;
						}
					}
				}
			}
		}	
	}
	
	// this is a round-robin tournament
	private static void playTournament()
	{
		// first we reset brains's fitness before they compete again
	    for(int i = 0; i < PARENTS + CHILDREN; ++i)
	    {
	    	fitness[i] = 0;
	    }
	    
	    // and also the games per generation
	    GEN_GAMES = 0;
		
	    // instantiate the class object
		Competition competition = new Competition();
		
		// create the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i] = new Thread(competition, Integer.toString(i));
		}
		
		// start the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i].start();
		}
		
		// wait for all threads to complete their task
		for(int i = 0; i < nThreads; ++i)
		{
			try 
			{
				tds[i].join();
			} 
			catch (InterruptedException e) 
			{
				// nothing to do...
				System.err.println("ERROR: Thread Interruption... Results might be inaccurate");
			}
		}
	}
	
	// saves the best brain in Disk and also some tournament statistics ...
	private static void saveBrain(double[] brain, String filename)
	{
		PrintWriter writer = null;
		
		try 
		{
			writer = new PrintWriter(filename);
			for(int i = 0; i < brain.length; ++i)
			{
				writer.print(brain[i] + " ");
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrain()\nBrain (" + filename + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}

	
	public static void main(String[] arg)
	{
		if(arg.length != 6)
		{
			System.err.println("Correct Usage: java -jar JCoEvESmpl.jar [parents] [children] [sigma] [nnType] [nnDepth] [threads]\n");
			System.err.println("NEURAL NETWORK TYPE");
			System.err.println("type = 0: 64-16x8-8-1,		type = 1: 64-16x8-8-4-1");
			System.err.println("type = 2: 64-91-40-10-1,	type = 3: 64-40-10-1");

			System.exit(1);
		}

		// parsing arguments ...
		PARENTS  = Integer.parseInt(arg[0]);	// parent population
		CHILDREN = Integer.parseInt(arg[1]);	// children population
		 sigma = Double.parseDouble(arg[2]); 	// initial sigma value
		netType  = Integer.parseInt(arg[3]); 	// Neural Network Type
		nnDepth  = Integer.parseInt(arg[4]); 	// the search depth of the AI
		nThreads = Integer.parseInt(arg[5]);	// The number of threads
		
		// testing arguments ...
		if(CHILDREN < PARENTS)
		{
			System.err.println("ERROR: Children should be more or equal to Parents. Insufficient Population");
			System.exit(1);
		}
		
		if(PARENTS < 1)
		{
			System.err.println("ERROR: Parents should be at least 1. Insufficient Population");
			System.exit(1);
		}
		
		if(sigma < 0.000001)
		{
			System.err.println("ERROR: Initial sigma value should be at least 0.000001");
			System.exit(1);
		}
		
		if(nnDepth < 1)
		{
			System.err.println("ERROR: Invalid Search Depth");
			System.exit(1);
		}
		
		if(netType < 0 || netType > 3)
		{
			System.err.println("ERROR: Invalid Network Type");
			System.exit(1);
		}

		if(nThreads < 1 || nThreads > PARENTS + CHILDREN)
		{
			System.err.println("ERROR: Invalid Number of Threads. Default value (1) is Used");
			nThreads = 1;
		}

		if(netType == 0) nWeights = 1185;
		else
		if(netType == 1) nWeights = 1217;
		else
		if(netType == 2) nWeights = 5900;
		else
		if(netType == 3) nWeights = 3021;
		
		GENERATIONS = 10000000;								// maximum number of generations
		double tau = 1/Math.sqrt(2.0*Math.sqrt(nWeights));	// for changes of specific elements
		double tau_prime = 1/Math.sqrt(2.0*nWeights);		// for general change in the mutation rate
		
		// create the first generation of "brains"
		brains = new double[PARENTS + CHILDREN][nWeights];
		for(int i = 0; i < PARENTS + CHILDREN; ++i)
		{	for(int w = 0 ; w < nWeights; ++w)
			{
				// each weight is initialized with a random value in [-0.1 , 0.1]
				brains[i][w] = 0.2*rvalue.nextDouble() - 0.1;
			}
		}
		
		// create the strategy parameters
		sigmas = new double[PARENTS + CHILDREN][nWeights];
		for(int i = 0; i < PARENTS + CHILDREN; ++i)
		{	for(int w = 0 ; w < nWeights; ++w)
			{
				// each strategy parameter is initialized to sigma
				sigmas[i][w] = sigma;
			}
		}
		
		// create their respective fitness values
		fitness = new int[PARENTS + CHILDREN];
		// create the thread pool
		tds = new Thread[nThreads];

		//////////////////////////////////////////////////////////////////
		System.out.println("Starting (μ + λ) Evolutionary Strategy ... ");
		// ***************************************************************
		//        CO-EVOLUTIONARY (μ + λ) ALGORITHM STARTS HERE 
	    // ***************************************************************

		int pi1, pi2;	// selected parents for discrete sexual recombination		
		int tmp_i;		// temporarily stores an integer value. used for swapping during sort
		double tmp_v;	// temporarily stores a real (double) value.
		
		long iniTime;
		
		for(int generation = 1; generation < GENERATIONS; ++generation)
		{
			// reset the timer
			iniTime = System.currentTimeMillis();
			
			// show some info about the generation number
			System.out.println("GENERATION: " + generation);

			// play a round-robin tournament to estimate the fitness of each individual
			playTournament();
			
			// show info about the games played
			System.out.printf("(%d) GAMES PLAYED - ", GEN_GAMES);
			
			// show elapsed time
			System.out.printf("ELAPSED TIME: %.2f sec\n", (double)(System.currentTimeMillis() - iniTime)/1000.0);
			
			// sort each individual according to its fitness to form the new parent population		
			for(int i = 0; i < PARENTS; ++i)
			{
				for(int j = i + 1; j < PARENTS + CHILDREN; ++j)
				{
					if(fitness[j] > fitness[i])
					{
						// swap fitness values
						tmp_i = fitness[i];
						fitness[i] = fitness[j];
						fitness[j] = tmp_i;
						
						// swap weights and strategy parameters
						for(int w = 0; w < nWeights; ++w)
						{
							tmp_v = brains[i][w];
							brains[i][w] = brains[j][w];
							brains[j][w] = tmp_v;

							tmp_v = sigmas[i][w];
							sigmas[i][w] = sigmas[j][w];
							sigmas[j][w] = tmp_v;
						}
					}
				}
			}

			// save the best "brain" of its generation
			saveBrain(brains[0], ("b_" + generation));
				
			// and show some additional info
			double meanF = 0.0;
			double stdF = 0.0;
				
			for(int i = 0; i < PARENTS; ++i) meanF += fitness[i];
			meanF = meanF/PARENTS;
				
			for(int i = 0; i < PARENTS; ++i) stdF += (fitness[i] - meanF)*(fitness[i] - meanF);
			stdF = Math.sqrt(stdF/PARENTS);
				
			System.out.println("Best Fitness: " + fitness[0] + "\tWorst Fitness: " + fitness[PARENTS-1]);
			System.out.printf ("Mean Fitness: %.1f\tstd-DEV: %.3f\n", meanF, stdF);
			System.out.println("-------------\n");

			
			// next we form the new children population through recombination and mutation
			int offspring;
			double global;
			
			for(int i = 0; i < CHILDREN; ++i)
			{
				offspring = PARENTS + i;

				// randomly select two parents from the population for recombination
				pi1 = rvalue.nextInt(PARENTS);
				pi2 = rvalue.nextInt(PARENTS);
				
				for(int w = 0; w < nWeights; ++w)
				{
					// discrete sexual recombination for weights
					if(rvalue.nextDouble() < 0.5)
					{
						brains[offspring][w] = brains[pi1][w];
					}
					else
					{
						brains[offspring][w] = brains[pi2][w];
					}

					// discrete sexual recombination for strategy parameters
					if(rvalue.nextDouble() < 0.5)
					{
						sigmas[offspring][w] = sigmas[pi1][w];
					}
					else
					{
						sigmas[offspring][w] = sigmas[pi2][w];
					}
				}

				// finally we perform mutation of child using parameter self-adaptation
				global = tau_prime*rvalue.nextGaussian();
				
				for(int w = 0; w < nWeights; ++w)
				{
					sigmas[offspring][w] = sigmas[offspring][w]*Math.exp(global + tau*rvalue.nextGaussian());
					// if strategy parameter becomes very small we set it to a threshold value
					// to prevent algorithm from stopping evolving
					if(sigmas[offspring][w] < 0.000001) sigmas[offspring][w] = 0.000001;

					brains[offspring][w] = brains[offspring][w] + sigmas[offspring][w]*rvalue.nextGaussian();
				}
			}
		}
	}
}
