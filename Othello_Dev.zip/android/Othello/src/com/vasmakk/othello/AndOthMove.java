package com.vasmakk.othello;

public class AndOthMove 
{
	private int mSquare;
	private int mColor;
	
	// the constructors
	public AndOthMove()
	{
		mSquare = 0;
		mColor = 0;
	}
	
	public AndOthMove(int square, int color)
	{
		mSquare = square;
		mColor = color;
	}
	
	// setters
	public void setSquare(int s)
	{
		mSquare = s;
	}
	
	public void setColor(int c)
	{
		mColor = c;
	}

	// getters...
	public int getSquare()
	{
		return mSquare;
	}
	
	public int getColor()
	{
		return mColor;
	}

}
