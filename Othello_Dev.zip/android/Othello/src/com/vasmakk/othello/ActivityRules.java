package com.vasmakk.othello;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.TextView;

public class ActivityRules extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rules);
		
		TextView tv = (TextView)findViewById(R.id.txt_game_rules);
		tv.setText(getRules());
	}
	
	private String getRules()
	{
		String out = "";
		
		try 
		{
			String line;
			
			AssetManager am = getResources().getAssets(); 
			BufferedReader in = new BufferedReader(new InputStreamReader(am.open("rules")));
			
			while((line = in.readLine()) != null)
			{
				out += line + "\n";
			}
			
			in.close();
			
		} 
		catch (IOException e) 
		{
			// nothing to do here ...
		}
		
		return out;
	}
}
