package com.vasmakk.othello;
import java.util.ArrayList;


public class AndOthManager 
{
	private static final int EMPTY = AndOthColors.blank;
	
	// Square labels of the Othello Board
	private static final String[] squares
	= {	"A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", 
		"A2", "B2", "C2", "D2", "E2", "F2", "G2", "H2",
		"A3", "B3", "C3", "D3", "E3", "F3", "G3", "H3",
		"A4", "B4", "C4", "D4", "E4", "F4", "G4", "H4",
		"A5", "B5", "C5", "D5", "E5", "F5", "G5", "H5",
		"A6", "B6", "C6", "D6", "E6", "F6", "G6", "H6",
		"A7", "B7", "C7", "D7", "E7", "F7", "G7", "H7",
		"A8", "B8", "C8", "D8", "E8", "F8", "G8", "H8"
	};
	
	
	// the next table, sorts the board squares in order of importance, so that they can be used
	// effectively inside the move generation module, and - later - inside alpha-beta pruning.
	private static final int[] ordered
	= {  0 ,  7 , 56 , 63 ,  2 ,  5 , 16 , 23 ,
		40 , 47 , 58 , 61 , 18 , 21 , 42 , 45 ,
		 3 ,  4 , 24 , 31 , 32 , 39 , 59 , 60 ,
		19 , 20 , 26 , 29 , 34 , 37 , 43 , 44 ,
		11 , 12 , 25 , 30 , 33 , 38 , 51 , 52 ,
		10 , 13 , 17 , 22 , 41 , 46 , 50 , 53 ,
		 1 ,  6 ,  8 , 15 , 48 , 55 , 57 , 62 ,
		 9 , 14 , 49 , 54	};
	
	// Direction tables: Starting from square i, the next jump is to the square Table[i]
	// or to nowhere, if Table[i] < 0 */
	public static final int[] U 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
	 	 0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 ,
	     8 ,  9 , 10 , 11 , 12 , 13 , 14 , 15 ,
	    16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 ,
	    24 , 25 , 26 , 27 , 28 , 29 , 30 , 31 ,
	    32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 ,
	    40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 ,
	    48 , 49 , 50 , 51 , 52 , 53 , 54 , 55 } ;

	public static final int[] UR 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
		 1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 , -1 ,
	     9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 } ;

	public static final int[] R 
	= {  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 , -1 ,
	     9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 ,
	    57 , 58 , 59 , 60 , 61 , 62 , 63 , -1 } ;

	public static final int[] DR 
	= {  9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 ,
	    57 , 58 , 59 , 60 , 61 , 62 , 63 , -1 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] D 
	= {  8 ,  9 , 10 , 11 , 12 , 13 , 14 , 15 ,
	    16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 ,
	    24 , 25 , 26 , 27 , 28 , 29 , 30 , 31 ,
	    32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 ,
	    40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 ,
	    48 , 49 , 50 , 51 , 52 , 53 , 54 , 55 ,
	    56 , 57 , 58 , 59 , 60 , 61 , 62 , 63 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] DL 
	= { -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 ,
	    -1 , 56 , 57 , 58 , 59 , 60 , 61 , 62 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] L 
	= { -1 ,  0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,
	    -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 ,
	    -1 , 56 , 57 , 58 , 59 , 60 , 61 , 62 } ;

	public static final int[] UL 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
	    -1 ,  0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,
	    -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 } ;


	// complete!
	public static int getSquareValue(String label)
	{
		for(int i = 0; i < 64; ++i)
			if(label.equalsIgnoreCase(squares[i])) return i;

		return -1;
	}
	
	// complete!
	public static String getSquareLabel(int value)
	{		
		if(value > 63 || value < 0) return "";
		return squares[value];
	}

	
	public static boolean isALegalMove(AndOthBoard board, int square, int color)
	{
		// examine only blank squares for candidate moves
		if(board.getSquareColor(square) == EMPTY)
		{
			int next;						// next square to examine ...
			boolean terminalDisk;			// if true, there is a terminal disk along the line
			boolean flippingDisk;			// if true, there is at least one candidate flipping disk
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 1st direction scan until the edge of the board or an empty square is reached...
			while((next = U[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 2nd direction scan until the edge of the board or an empty square is reached...
			while((next = UR[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 3rd direction scan until the edge of the board or an empty square is reached...
			while((next = R[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 4th direction scan until the edge of the board or an empty square is reached...
			while((next = DR[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 5th direction scan until the edge of the board or an empty square is reached...
			while((next = D[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 6th direction scan until the edge of the board or an empty square is reached...
			while((next = DL[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 7th direction scan until the edge of the board or an empty square is reached...
			while((next = L[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 8th direction scan until the edge of the board or an empty square is reached...
			while((next = UL[next]) > -1 && board.getSquareColor(next) != EMPTY)	
			{
				if(board.getSquareColor(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
		}
		
		return false;
	}
	

	public static ArrayList<AndOthMove> getLegalMoves(AndOthBoard board, int color)
	{
		int orderedSquare;
		ArrayList<AndOthMove> moveList = new ArrayList<AndOthMove> ();
		
		for(int square = 0; square < 60; ++square)
		{
			orderedSquare = ordered[square];
			
			if(isALegalMove(board, orderedSquare, color))
			{
				moveList.add(new AndOthMove(orderedSquare, color));
			}
		}
		
		return moveList;
	}


	public static void playMove(AndOthBoard board, AndOthMove move)
	{
		int next;						// next square to examine ...
		int square = move.getSquare();	// the starting square
		int color = move.getColor();	// the flipping color 
		boolean terminalDisk;			// if true, there is a terminal disk along the line
		boolean flippingDisk;			// if true, there is at least one candidate flipping disk
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 1st direction scan until the edge of the board or an empty square is reached...
		while((next = U[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = D[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		  
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 2nd direction scan until the edge of the board or an empty square is reached...
		while((next = UR[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = DL[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
			  
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 3rd direction scan until the edge of the board or an empty square is reached...
		while((next = R[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = L[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 4th direction scan until the edge of the board or an empty square is reached...
		while((next = DR[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = UL[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 5th scan until the edge of the board or an empty square is reached...
		while((next = D[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = U[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 6th direction scan until the edge of the board or an empty square is reached...
		while((next = DL[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = UR[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 7th direction scan until the edge of the board or an empty square is reached...
		while((next = L[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = R[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 8th direction scan until the edge of the board or an empty square is reached...
		while((next = UL[next]) > -1 && board.getSquareColor(next) != EMPTY)	
		{
			if(board.getSquareColor(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = DR[next]) != square)
			{
				board.setSquareColor(next, color);
			}
			
			board.setSquareColor(square, color);
		}
	}
}
