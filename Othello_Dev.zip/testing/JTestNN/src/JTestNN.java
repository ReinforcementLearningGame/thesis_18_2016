////////////////////////////////////////////////////////////////////////////////////////
//                       This is For Testing of all Neural Networks
////////////////////////////////////////////////////////////////////////////////////////

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;


public class JTestNN
{
	// brains are tested with both colors for a number of positions
	private static int TEST_CYCLES;		// the number of test cycles. Each cycle, a game is played with both colors
	private static int GAMES_PLAYED;	// actual games played
	private static int KEEP_NBEST;		// number of best results to keep through generations
	
	private static int wins, draws, losses;		// The performance of the tested player
	private static int bG[], bW[], bD[], bL[];	// The best (N) results, through generations
	
	private static double[] brain;		// The brain stored in disk

	static int netSave;
	static int netType;
	static int nnDepth;
	static int aiDepth;
	
	// for multi-threaded tasks...
	private static int nThreads;		// number of threads
	private static Thread[] tds;		// an array of threads
	
	
	static class Competition implements Runnable
	{
		@Override
		public void run() 
		{
			int ds1, ds2;	// disks for each player, after one game
			int thrGames;	// number of games per thread
			
			
			if(Thread.currentThread().getName().equals("0"))
				thrGames = TEST_CYCLES / nThreads + TEST_CYCLES % nThreads;
			else
				thrGames = TEST_CYCLES / nThreads;
			
			
			OthBoard board = new OthBoard();
			
			OthAIPlayer p1 = null;
			OthAIPlayer p2 = new AIStdEval();

			if(netType == 0) p1 = new NN_64_16x8_8_1();
			else
			if(netType == 1) p1 = new NN_64_16x8_8_4_1();
			else
			if(netType == 2) p1 = new NN_64_91_40_10_1();
			else
			if(netType == 3) p1 = new NN_64_40_10_1();
			
			p1.setBrain(brain);
			p2.setBrain(new int[] { 1000, -225, -402, -5, -168, -44, -29, -141, -63, -3, 319, 3 });
			
			p1.setDepth(nnDepth);
			p2.setDepth(aiDepth);
			
			for(int p = 0; p < thrGames; ++p)
			{
				// setting up the board and the players's color
				board.reset();
							
				p1.setColor(OthColors.black);
				p2.setColor(OthColors.white);
							
				// this is the first game where p1 plays black and p2 plays white
				OthManager.playQuietly(board, p1, p2);

				ds1 = board.getDisksOfColor(OthColors.black);
				ds2 = board.getDisksOfColor(OthColors.white);
				
				synchronized(this)
				{
					++GAMES_PLAYED;
					
					if(ds1 > ds2)
					{
						++wins;
					}
					else
					if(ds1 < ds2)
					{
						++losses;
					}
					else
					{
						++draws;
					}
				}
							
				// setting up the board and the players's color
				board.reset();
				
				p2.setColor(OthColors.black);
				p1.setColor(OthColors.white);
							
				// this is the second game where p2 plays black and p1 plays white
				OthManager.playQuietly(board, p2, p1);
				
				ds2 = board.getDisksOfColor(OthColors.black);
				ds1 = board.getDisksOfColor(OthColors.white);
				
				synchronized(this)
				{
					++GAMES_PLAYED;
					
					if(ds2 > ds1)
					{
						++losses;
					}
					else
					if(ds2 < ds1)
					{
						++wins;
					}
					else
					{
						++draws;
					}
				}
			}
		}	
	}
	
	// a number of games between the two "brains" is played
	private static void playGames()
	{
		// reset games played
		GAMES_PLAYED = 0;
		
		// reset the p1 player's scores
		wins = 0;
		draws = 0;
		losses = 0;
		
		// instantiate the class object
		Competition competition = new Competition();
		
		// create the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i] = new Thread(competition, Integer.toString(i));
		}
		
		// start the threads
		for(int i = 0; i < nThreads; ++i)
		{
			tds[i].start();
		}
		
		// wait for all threads to complete their task
		for(int i = 0; i < nThreads; ++i)
		{
			try 
			{
				tds[i].join();
			} 
			catch (InterruptedException e) 
			{
				// nothing to do...
				System.err.println("ERROR: Thread Interruption... Results might be inaccurate");
			}
		}
	}

	// load Neural Net's weights from disk
	private static double[] loadBrain(String filename)
	{
		BufferedReader reader = null;
		double[] nnBrain = null;
		
		try 
		{
			String line;
			reader = new BufferedReader(new FileReader(filename));
			
			line = reader.readLine();
			line = line.trim();

			String[] weights = line.split("\\s");
			nnBrain = new double[weights.length];
			
			for(int i = 0; i < weights.length; ++i) nnBrain[i] = Double.parseDouble(weights[i]);
			
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method loadBrain()\nBrain (" + filename + ") not loaded ...");
		}
		finally
		{
			if(reader != null)
			try 
			{
				reader.close();
			} 
			catch (IOException e)
			{
				// nothing to do here...
			}
		}
		
		return nnBrain;
	}

	// saves the brain's tournament statistics to Disk ...
	private static void saveBrainResults(String filename, int generation)
	{
		PrintWriter writer = null;
		
		try 
		{
			writer = new PrintWriter(filename);
		
			writer.printf("GENERATION: %d\nWins Draws Losses: %d %d %d\nLoss Percentage: %10.6f(%%)", 
			generation, wins, draws, losses, 100.0f*((float)losses)/(wins+draws+losses));
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrainResults()\nBrain Results (" + generation + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}
	
	// saves the best brain's tournament statistics to Disk ...
	private static void saveNBestResults(String filename, int generation)
	{
		PrintWriter writer = null;
		
		// find a spot among (N) best results
		for(int i = 0; i < KEEP_NBEST; ++i)
		{
			if(losses > bL[i] && bG[i] > 0) continue;
			
			for(int j = KEEP_NBEST - 1; j > i; --j)
			{
				bG[j] = bG[j-1];
				bW[j] = bW[j-1];
				bD[j] = bD[j-1];
				bL[j] = bL[j-1];
			}
			
			bG[i] = generation;
			bW[i] = wins;
			bD[i] = draws;
			bL[i] = losses;
			
			break;
		}
		
		try 
		{
			writer = new PrintWriter(filename);
		
			for(int i = 0; i < KEEP_NBEST; ++i)
			{
				if(bG[i] > 0)
				{
					writer.printf("GENERATION: %d\nWins Draws Losses: %d %d %d\nLoss Percentage: %10.6f(%%)\n\n", 
					bG[i], bW[i], bD[i], bL[i], 100.0f*((float)bL[i])/(bW[i] + bD[i] + bL[i]));
				}
			}
		}
		catch (IOException e)
		{
			System.err.println("I/O Error in method saveBrainResults()\nBrain Results (" + generation + ") not saved ...");
		}
		finally
		{
			if(writer != null) writer.close();
		}
	}
	
	private static boolean isWithinRange(int generation, int from, int to)
	{
		return Math.abs(generation - from) <= Math.abs(to - from);
	}
	
	public static void main(String[] args)
	{
		if(args.length != 9)
		{
			System.err.println("Correct Usage: java -jar JTestNN.jar [from_gen] [to_gen] [step] [cycles] [save] [nnType] [nn_Depth] [ai_depth] [threads]");
			System.err.println("save = 0: Save only best performances, save = 1: Save every performance...");
			System.err.println("type = 0: 64-16x8-8-1,		type = 1: 64-16x8-8-4-1");
			System.err.println("type = 2: 64-91-40-10-1,	type = 3: 64-40-10-1");
			System.exit(1);
		}
		
		// parsing arguments ...
		int FROM_GENERATION = Integer.parseInt(args[0]);
		int TO_GENERATION = Integer.parseInt(args[1]);
		int GENERATION_STEP = Integer.parseInt(args[2]);
		TEST_CYCLES = Integer.parseInt(args[3]);
		
		netSave = Integer.parseInt(args[4]);
		netType = Integer.parseInt(args[5]);
		nnDepth = Integer.parseInt(args[6]);
		aiDepth = Integer.parseInt(args[7]);
		
		nThreads = Integer.parseInt(args[8]);
		
		// testing arguments ...
		if((FROM_GENERATION < TO_GENERATION) && GENERATION_STEP > 0)
		{
			// limits are O.K. do nothing ...
		}
		else
		if((FROM_GENERATION > TO_GENERATION) && GENERATION_STEP < 0)
		{
			// limits are O.K. do nothing ...
		}
		else
		{
			System.err.println("ERROR: Invalid Generation Limits");
			System.exit(1);
		}
		
		if(GENERATION_STEP == 0)
		{
			System.err.println("ERROR: Invalid Generation Step");
			System.exit(1);
		}
		
		if(nThreads < 1 || nThreads > TEST_CYCLES)
		{
			System.err.println("ERROR: Invalid Number of Threads. Default value (1) is Used");
			nThreads = 1;
		}
		
		if(nnDepth < 1)
		{
			System.err.println("ERROR: Invalid NN Search Depth");
			System.exit(1);
		}
		
		if(aiDepth < 1)
		{
			System.err.println("ERROR: Invalid AI Search Depth");
			System.exit(1);
		}
		
		if(netType < 0 || netType > 3)
		{
			System.err.println("ERROR: Invalid Network Type");
			System.exit(1);
		}
		
		if(netSave != 0 && netSave != 1)
		{
			System.err.println("ERROR: Invalid Save Option");
			System.exit(1);
		}
		
		tds = new Thread[nThreads];
		
		/****************************************************
		 *      START TESTING PLAYERS AGAINST PROROTYPE
		 * *************************************************/

		KEEP_NBEST = 20;			// keep and save the best (n) results
		bG = new int[KEEP_NBEST];
		bW = new int[KEEP_NBEST];
		bD = new int[KEEP_NBEST];
		bL = new int[KEEP_NBEST];
		
		
		long iniTime;
		
		float bestPercentage = 100.0f;
		float percentage;
		
		int bestGen = 0;
		int bestWins = 0;
		int bestDraws = 0;
		int bestLosses = 0;

		for(int generation  = FROM_GENERATION; isWithinRange(generation, FROM_GENERATION, TO_GENERATION); 
				generation += GENERATION_STEP)
		{
			iniTime = System.currentTimeMillis();
				
			// load brain from file
			brain = loadBrain("b_" + generation);
				
			// play a number of predefined games with prototype
			playGames();
				
			percentage = 100.0f*((float)losses)/(wins+draws+losses);
				
			// save results to disk
			if(netSave == 1)
			{
				saveNBestResults("top_20"  , generation);
				saveBrainResults("results_" + generation, generation);
			}
				
			if(percentage <= bestPercentage)
			{
				bestPercentage = percentage;
					
				bestGen = generation;
				bestWins = wins;
				bestDraws = draws;
				bestLosses = losses;
				
				if(netSave == 0) saveBrainResults("rBest_" + generation, generation);
			}
				
			// and finally report the results
			System.out.printf("GENERATION: %d\n", generation);

			System.out.printf("Wins Draws Losses: %d %d %d Loss Percentage: %.6f(%%)\n", 
					wins, draws, losses, percentage);
				
			System.out.printf("Wins Draws Losses: %d %d %d Loss Percentage: %.6f(%%) - Gen %d\n", 
					bestWins, bestDraws, bestLosses, bestPercentage, bestGen);
				
			System.out.printf("(%d) Games Played - ", GAMES_PLAYED);
			System.out.printf("ELAPSED TIME: %.2f sec\n\n", (double)(System.currentTimeMillis() - iniTime)/1000.0);
		}
	}
}