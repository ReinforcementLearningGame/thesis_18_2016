import java.util.ArrayList;


public class OthManager 
{
	// Direction tables: Starting from square i, the next jump is to square Table[i]
	//   if Table[i] > -1 */

	public static final int[] U 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
	 	 0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 ,
	     8 ,  9 , 10 , 11 , 12 , 13 , 14 , 15 ,
	    16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 ,
	    24 , 25 , 26 , 27 , 28 , 29 , 30 , 31 ,
	    32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 ,
	    40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 ,
	    48 , 49 , 50 , 51 , 52 , 53 , 54 , 55 } ;

	public static final int[] UR 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
		 1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 , -1 ,
	     9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 } ;

	public static final int[] R 
	= {  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,  7 , -1 ,
	     9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 ,
	    57 , 58 , 59 , 60 , 61 , 62 , 63 , -1 } ;

	public static final int[] DR 
	= {  9 , 10 , 11 , 12 , 13 , 14 , 15 , -1 ,
	    17 , 18 , 19 , 20 , 21 , 22 , 23 , -1 ,
	    25 , 26 , 27 , 28 , 29 , 30 , 31 , -1 ,
	    33 , 34 , 35 , 36 , 37 , 38 , 39 , -1 ,
	    41 , 42 , 43 , 44 , 45 , 46 , 47 , -1 ,
	    49 , 50 , 51 , 52 , 53 , 54 , 55 , -1 ,
	    57 , 58 , 59 , 60 , 61 , 62 , 63 , -1 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] D 
	= {  8 ,  9 , 10 , 11 , 12 , 13 , 14 , 15 ,
	    16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 ,
	    24 , 25 , 26 , 27 , 28 , 29 , 30 , 31 ,
	    32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 ,
	    40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 ,
	    48 , 49 , 50 , 51 , 52 , 53 , 54 , 55 ,
	    56 , 57 , 58 , 59 , 60 , 61 , 62 , 63 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] DL 
	= { -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 ,
	    -1 , 56 , 57 , 58 , 59 , 60 , 61 , 62 ,
	    -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 } ;

	public static final int[] L 
	= { -1 ,  0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,
	    -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 ,
	    -1 , 56 , 57 , 58 , 59 , 60 , 61 , 62 } ;

	public static final int[] UL 
	= { -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 ,
	    -1 ,  0 ,  1 ,  2 ,  3 ,  4 ,  5 ,  6 ,
	    -1 ,  8 ,  9 , 10 , 11 , 12 , 13 , 14 ,
	    -1 , 16 , 17 , 18 , 19 , 20 , 21 , 22 ,
	    -1 , 24 , 25 , 26 , 27 , 28 , 29 , 30 ,
	    -1 , 32 , 33 , 34 , 35 , 36 , 37 , 38 ,
	    -1 , 40 , 41 , 42 , 43 , 44 , 45 , 46 ,
	    -1 , 48 , 49 , 50 , 51 , 52 , 53 , 54 } ;


	// complete!
	public static int getSquareValue(String sqLab)
	{
		String s = sqLab.substring(0, 1);
		String n = sqLab.substring(1, 2);
		
		int col = "ABCDEFGH".indexOf(s);
		int row = "12345678".indexOf(n);

		return row*8 + col;
	}
	
	// complete!
	public static String getSquareLabel(int sqVal)
	{		
		int col = sqVal % 8;
		int row = sqVal / 8;
			
		String s = "ABCDEFGH".substring(col, col + 1);
		String n = "12345678".substring(row, row + 1);
			
		return s + n;
	}

	
	// complete!
	public static boolean isLegalMove(OthBoard board, int square, int color)
	{
		// examine only blank squares for candidate moves
		if(board.getColorOfSquare(square) == OthColors.blank)
		{
			int next;						// next square to examine ...
			boolean terminalDisk;			// if true, there is a terminal disk along the line
			boolean flippingDisk;			// if true, there is at least one candidate flipping disk
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 1st direction scan until the edge of the board or an empty square is reached...
			while((next = U[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 2nd direction scan until the edge of the board or an empty square is reached...
			while((next = UR[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 3rd direction scan until the edge of the board or an empty square is reached...
			while((next = R[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 4th direction scan until the edge of the board or an empty square is reached...
			while((next = DR[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 5th direction scan until the edge of the board or an empty square is reached...
			while((next = D[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 6th direction scan until the edge of the board or an empty square is reached...
			while((next = DL[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 7th direction scan until the edge of the board or an empty square is reached...
			while((next = L[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
			
			terminalDisk = false;
			flippingDisk = false;
			next = square;
			
			// 8th direction scan until the edge of the board or an empty square is reached...
			while((next = UL[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
			{
				if(board.getColorOfSquare(next) == color)
				{
					terminalDisk = true; 
					break;
				}
				
				flippingDisk = true;
			}
			
			if(terminalDisk && flippingDisk) return true;
		}
		
		return false;
	}
	
	// complete!
	public static ArrayList<OthMove> getLegalMoves(OthBoard board, int color)
	{
		ArrayList<OthMove> moveList = new ArrayList<OthMove> ();
		for(int square = 0; square < 64; ++square)
		{
			if(isLegalMove(board, square, color))
			{
				moveList.add(new OthMove(square, color));
			}
		}
		
		return moveList;
	}

	// complete!
	public static void playMove(OthBoard board, OthMove move)
	{
		int next;						// next square to examine ...
		int square = move.getSquare();	// the starting square
		int color = move.getColor();	// the flipping color 
		boolean terminalDisk;			// if true, there is a terminal disk along the line
		boolean flippingDisk;			// if true, there is at least one candidate flipping disk
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 1st direction scan until the edge of the board or an empty square is reached...
		while((next = U[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = D[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		  
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 2nd direction scan until the edge of the board or an empty square is reached...
		while((next = UR[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = DL[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
			  
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 3rd direction scan until the edge of the board or an empty square is reached...
		while((next = R[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = L[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 4th direction scan until the edge of the board or an empty square is reached...
		while((next = DR[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = UL[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 5th scan until the edge of the board or an empty square is reached...
		while((next = D[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = U[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 6th direction scan until the edge of the board or an empty square is reached...
		while((next = DL[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = UR[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 7th direction scan until the edge of the board or an empty square is reached...
		while((next = L[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = R[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
		
		terminalDisk = false;
		flippingDisk = false;
		next = square;
		
		// 8th direction scan until the edge of the board or an empty square is reached...
		while((next = UL[next]) > -1 && board.getColorOfSquare(next) != OthColors.blank)	
		{
			if(board.getColorOfSquare(next) == color)
			{
				terminalDisk = true; 
				break;
			}
			
			flippingDisk = true;
		}
		
		if(terminalDisk && flippingDisk)
		{
			// we work backwards here to flip the whole line...
			while((next = DR[next]) != square)
			{
				board.setColorOfSquare(next, color);
			}
			
			board.setColorOfSquare(square, color);
		}
	}
	
	// complete!
	public static void playOthello(OthBoard board, OthPlayer p1, OthPlayer p2)
	{
		OthMove mv;
		int passes = 0;
		
		board.view();
		while(true)
		{
			// p1 always plays first
			mv = p1.nextMove(board);
			if(mv == null) 
			{
				++passes;
				System.out.println("Player #1: PASS");
			}
			else passes = 0;
			
			if(passes == 2) break;	// two passes in a row, game is over...
			if(passes == 0) playMove(board, mv);
			
			if(mv != null)
			{
				System.out.println("Player #1: " + getSquareLabel(mv.getSquare()));
				if(p1 instanceof OthAIPlayer) System.out.println("Score: " + ((OthAIPlayer)p1).getScore());
				board.view();
			}
			
			
			// p2 always plays second
			mv = p2.nextMove(board);
			if(mv == null) 
			{
				++passes;
				System.out.println("Player #2: PASS");
			}
			else passes = 0;
						
			if(passes == 2) break;	// two passes in a row, game is over...
			if(passes == 0) playMove(board, mv);
			
			if(mv != null)
			{
				System.out.println("Player #2: " + getSquareLabel(mv.getSquare()));
				if(p2 instanceof OthAIPlayer) System.out.println("Score: " + ((OthAIPlayer)p2).getScore());
				board.view();
			}
		}
		
		System.out.println("-------------------------");
		System.out.println("BLACK: " + board.getDisksOfColor(OthColors.black));
		System.out.println("WHITE: " + board.getDisksOfColor(OthColors.white));
	}
	
	// complete!
	public static void playQuietly(OthBoard board, OthPlayer p1, OthPlayer p2)
	{
		OthMove mv;
		int passes = 0;
				
		while(true)
		{
			// p1 always plays first
			mv = p1.nextMove(board);
			if(mv == null) 
			{
				++passes;
			}
			else passes = 0;
			
			if(passes == 2) break;	// two passes in a row, game is over...
			if(passes == 0) playMove(board, mv);			
			
			// p2 always plays second
			mv = p2.nextMove(board);
			if(mv == null) 
			{
				++passes;
			}
			else passes = 0;
						
			if(passes == 2) break;	// two passes in a row, game is over...
			if(passes == 0) playMove(board, mv);
		}
	}
}
