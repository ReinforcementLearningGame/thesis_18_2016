
public abstract class OthAIPlayer extends OthPlayer 
{
	public abstract String getScore();			// a string representation of the move score ...
	public abstract void setDepth(int depth);
	
	// this method must be necessarily implemented at the derived class
	public void setBrain(int[] brain)
	{
		// nothing to do here...
	}
	
	// this method must be necessarily implemented at the derived class
	public void setBrain(double[] brain)
	{
		// nothing to do here...
	}
}
