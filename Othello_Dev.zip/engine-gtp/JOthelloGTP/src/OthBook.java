import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;


public class OthBook 
{
	private ArrayList <String> openingsList;
	private ArrayList <String> movesList;
	private Random rvalue;
	
	
	public OthBook(String filename)
	{
		rvalue = new Random(System.currentTimeMillis());
		openingsList = new ArrayList <String> ();
		movesList = new ArrayList <String> ();

		BufferedReader in;
		try
		{
			in = new BufferedReader(new FileReader(filename));
			String line;
			String [] opening;
			
			while((line = in.readLine()) != null)
			{
				opening = line.split("=");
				openingsList.add(opening[0].trim());
			}
			
			in.close();
		}
		catch(IOException e)
		{
			openingsList.clear();;
		}
	}
	
	
	public String reply(String moveSequence)
	{
		if(moveSequence != null)
		{
			movesList.clear();
		
			String opening;
			for(int i = 0; i < openingsList.size(); ++i)
			{
				opening = openingsList.get(i);
				
				if(opening.startsWith(moveSequence)	&& moveSequence.length() + 2 <= opening.length())
				{
					movesList.add(opening.substring(moveSequence.length(), moveSequence.length() + 2));
				}
			}
		
			if(!movesList.isEmpty()) return movesList.get(rvalue.nextInt(movesList.size()));
		}
		
		return "";
	}
}
