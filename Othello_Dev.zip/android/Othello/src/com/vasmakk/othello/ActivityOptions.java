package com.vasmakk.othello;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;

public class ActivityOptions extends Activity
{
	private Button bng;
	private Spinner spp, spm, spe;
	private RadioButton rbb, rbw;
	private CheckBox chkBook, chkSound;
	
	private final int BLACK = AndOthColors.black;
	private final int WHITE = AndOthColors.white;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);        
        setContentView(R.layout.activity_options);
        
        bng = (Button) findViewById(R.id.btn_new_game);
        bng.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View v)
			{
				startActivity(new Intent(ActivityOptions.this, ActivityLaunch.class));
			}
        	
        });
        
        chkBook = (CheckBox)findViewById(R.id.chk_opening_book);
        chkBook.setChecked(GameOptions.openingBook);
        chkBook.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) 
			{
				GameOptions.openingBook = !GameOptions.openingBook;
			}
        });
        
        chkSound = (CheckBox)findViewById(R.id.chk_sound_effects);
        chkSound.setChecked(GameOptions.soundEffects);
        chkSound.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) 
			{
				GameOptions.soundEffects = !GameOptions.soundEffects;
			}
        });
        
        rbb = (RadioButton)findViewById(R.id.rad_black);
        rbb.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) 
			{
				GameOptions.aiColor = WHITE;
			}
        });
        
        rbw = (RadioButton)findViewById(R.id.rad_white);
        rbw.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) 
			{
				GameOptions.aiColor = BLACK;
			}
        });
        
		if(GameOptions.aiColor == BLACK) 
		{
			rbw.setChecked(true);
		}
		else
		{
			rbb.setChecked(true);
		}
        

        ArrayAdapter<String> ad1;
        ad1 = new ArrayAdapter<String>(this, R.layout.spinner_layout, GameOptions.personalities);

        spp = (Spinner)findViewById(R.id.spn_personality);
        spp.setAdapter(ad1);
        spp.setSelection(GameOptions.personalitiesIndex);
        
        spp.setOnItemSelectedListener(new OnItemSelectedListener()
        {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
			{
				GameOptions.personalityType = GameOptions.personalityTypes[position];
				GameOptions.personalityFile = GameOptions.personalityFiles[position];
				GameOptions.personalitiesIndex = position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent)
			{
				GameOptions.personalityType = GameOptions.personalityTypes[0];
				GameOptions.personalityFile = GameOptions.personalityFiles[0];
				GameOptions.personalitiesIndex = 0;
			}
        });
        
        ArrayAdapter<String> ad2;
        ad2 = new ArrayAdapter<String>(this, R.layout.spinner_layout, GameOptions.midgameSearchDepth);
        
        spm = (Spinner)findViewById(R.id.spn_midgame_search_depth);
        spm.setAdapter(ad2);
        spm.setSelection(GameOptions.midgameSearchIndex);
        
        spm.setOnItemSelectedListener(new OnItemSelectedListener()
        {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
			{
				GameOptions.midgameSearchIndex = position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent)
			{
				GameOptions.midgameSearchIndex = 0;
			}
        });
        
        ArrayAdapter<String> ad3;
        ad3 = new ArrayAdapter<String>(this, R.layout.spinner_layout, GameOptions.endgameSearchDepth);
        
        spe = (Spinner)findViewById(R.id.spn_endgame_search_depth);
        spe.setAdapter(ad3);
        spe.setSelection(GameOptions.endgameSearchIndex);
        
        spe.setOnItemSelectedListener(new OnItemSelectedListener()
        {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
			{
				GameOptions.endgameSearchIndex = position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent)
			{
				GameOptions.endgameSearchIndex = 0;
			}
        });
    }
}
